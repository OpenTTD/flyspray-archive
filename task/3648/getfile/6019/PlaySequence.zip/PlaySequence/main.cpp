#include <CoreServices/CoreServices.h>
#include <AudioToolbox/AudioToolbox.h>
#include <unistd.h>

/*
 Use the following environment variable to activate libgmalloc
 
 set env DYLD_INSERT_LIBRARIES /usr/lib/libgmalloc.dylib
 
 There is a memory error when the file is played
 */

int main (int argc, const char * argv[]) 
{
	OSStatus		result = noErr;
	const char		*filePath = "fail.mid";
	
	CFURLRef		url= nil;
	MusicPlayer		player = nil;
	MusicSequence	sequence = nil;
	AUGraph			graph = nil;
	
	url = CFURLCreateFromFileSystemRepresentation(kCFAllocatorDefault, (const UInt8*)filePath, strlen(filePath), false);
	
	require_noerr (result = NewMusicPlayer (&player), fail);
	require_noerr (result = NewMusicSequence(&sequence), fail);
	require_noerr (result = MusicSequenceFileLoad (sequence, url, 0, 0), fail);
	require_noerr (result = MusicSequenceGetAUGraph (sequence, &graph), fail);
	require_noerr (result = AUGraphOpen (graph), fail);     
	require_noerr (result = AUGraphInitialize (graph), fail);
	
	require_noerr (result = MusicPlayerSetSequence (player, sequence), fail);
	require_noerr (result = MusicPlayerSetTime (player, 0.0f), fail);
	require_noerr (result = MusicPlayerPreroll (player), fail);
	require_noerr (result = MusicPlayerStart (player), fail);
	sleep(2);
	require_noerr (result = MusicPlayerStop (player), fail);
	require_noerr (result = DisposeMusicPlayer (player), fail);
	require_noerr (result = DisposeMusicSequence(sequence), fail);
		
    return 0;
fail:
	return result;
}
