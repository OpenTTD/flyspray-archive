Total Town Replacement Set v3.02a readme
=======================================

What does it contain?
---------------------

Total Town Replacement Set v3 (TTRSv3 for short) is a building set for TTDPatch, for the temperate,
arctic and tropic climates. It contains over 100 town buildings to break the monotony you get with
default TTD town buildings. The buildings are separated into four "eras", 1920-1950, 1950-1980,
1980-2010 and 2010-forever. This means your towns will nicely evolve from old-style buildings towards
modern buildings as time passes in the game.

The set comes with some extras as well. The small airport, big airport and heliport graphics are replaced
to make them fit to the buildings. There are two bank versions that replace the original bank and have
different looks in the different eras. You also get two new road graphics, one used before 1970, and one
used after that year. Town bridge graphics are also replaced. Everything except the bank can be turned off
in case you want to use different graphics for these things, or simply prefer the original TTD ones.

The set is compatible with the Extended Cargo Scheme project, thanks to George. When petrol is available
in your game, towns will start building petrol stations that accept it. Similarly, when the "tourist"
cargo is available, some of the buildings will start accepting and producing tourists. This set is, however,
also fully functional without using ECS.

Requirements
------------

TTDPatch 2.5 beta 9 or 2.6 alpha r1220 is required. 2.5 beta 9 has some bugs that may cause
problems, though (see the section "Known problems" below). These problems will be fixed in the next beta version.

You need the "newhouses" switch to be activated for the set to work. You won't see the new bank graphics unless
you have "newindustries" enabled as well. For the new road bridges to work correctly, you need to turn the "newbridges"
switch on.

How to use
----------

First, copy "ttrs3.grf" (if you have the DOS version of TTD) or "ttrs3w.grf"
(if you have the Windows version) to the "newgrf" directory inside your TTD
directory. Then open "newgrf[w].cfg" (the "w" is needed for the Windows version),
and add the following line:

newgrf/ttrs3[w].grf

Again, the "w" is needed for the Windows version.

Optionally, you can add up to four numbers (parameters) to the end of the line.

These parameters have the following meaning:

 1st	0 - Use the new building types only, default TTD buildings are disabled
	1 (default) New house types are added without modifying the old types, 
	  so towns will have both original TTD and new buildings.

 2nd	0 (default) time sequence is followed
	1 - Force the 1920-1950 era. This means that the graphics for this era are used no matter what year
            it actually is in the game.
	2 - Force the 1950-1980 era.
	3 - Force the 1980-2010 era.
	4 - Force the 2010-forever era.
	5 - Mix all eras. This means buildings from all eras can appear no matter what year it is in the game.

 3rd	0 - Don't use TTRS-v3 townroads and bridges
	1 - Use TTRS-v3 townroads and default TTD road bridges
	2 (default) Use TTRS-v3 townroads and replace road bridge graphics

 4th	0 (default for TTDPatch) Use TTRS-v3 airports.
	1 (default for OpenTTD) do not use TTRS-v3 airports

If you don't set these parameters in your newgrf[w].cfg file, the default settings
will be used.

If you're using the road bridge replacements (enabled by default), it is recommended to use the
girder steel bridge (the one whose icon is a grey arch) in towns, since its graphics look the best
inside towns.

There is a small problem with the roads because of a limitation of TTDPatch: the roads can't change
automatically in 1970. To work around this, you can do two things when you reach 1970 in your game:
a) open the GRF Settings window and press Apply without changing anything;
b) save the game and load it back.
Any of these two will make the new roads appear.

The new heliport graphics have the same limitation. They should change in 1980 and 2010, but this won't
actually happen unless you do one of the above two points.

Incompatible sets
-----------------

This set isn't compatible with older versions of TTRS. There are just too many changes to make it compatible,
so you're better off starting a new game with the new version. You can activate the set in existing games
as well, of course, but it will take some time for the new buildings to appear as towns gradually replace
their existing buildings.

Similarly, you can't use George's "TTRS3 alpha" set with this set. All buildings of that set is included in
this set, so this shouldn't be a problem.

When TTRS3 detects one of these sets below itself in the newgrfw.cfg file, it will deactivate them and
notify you with a warning. If, however, this set is below those two, it will deactivate itself instead,
and show an error about the incompatibility. If you disable those sets manually, everything will work fine.

Known problems
--------------

TTDPatch 2.5 beta 9 has a bug that messes up all your buildings when you enable a building set in an existing
game, and this affects TTRS3 too. Until the next beta comes out, you can either use TTRS3 in new games only,
or use 2.6 alpha.

In 2.5 beta 9 and earlier, there is a problem that messes up the bridge graphics when you open the GRF Settings
window, make some changes and then DON'T press Apply but close the window. To work around this, just open the
window again and press Apply without changing anything.

The buildings in this set are fully snow-aware since v3.02. This means they can change their graphics dynamically
when the snow line height changes. Original arctic TTD buildings can't do this, though. Therefore, if you plan
to use variable snow line height GRFs, it's best to disable all original buildings by setting parameter 1 to 0.

The set uses some features that are available in 2.6 alphas only. It will work correctly in 2.5 versions as well,
but these features won't be available. The differences will be very small.  For example, the last remaining old water
tower will be protected from destruction and becomes a historical building if you use 2.6, but this is
impossible in 2.5.

Changelog
---------

Changes in v3.02a:
-Fixed Hotel Regent and Hotel Pribaltiskaya graphics
-Fixed snowy newroads tunnel entrances
-Fixed a bug with the new bridge replacements

Changes in v3.02:
-Added snowy versions of buildings
-Replaced cargobay graphics
-Added crossings for monorail and maglev
-Added roads and crossings for arctic and tropic
-Changed how parameter 3 works
-Added new road bridges, activated by setting param. 3 to 2
 (this is the default now)
-Added heliport graphics for 3 eras
-Added different grass for some buildings on arctic and tropic
-Added food acceptance to houses A..E

Changes in v3.01:
-Decreased the removal rating of George's statues to 500; now they can be removed with good LA rating
-Fixed version detection - now a correct error message appears in older versions instead of invalid sprite errors
-Fixed most problems reported by DaleStan and NFORenum
-New airports are now default-off in OTTD
-Added snowy roads, tunnels and crossings
-Added other bridges with Zimmlock's roads
-Restricted the 2010-forever Modern Office Block to height level 10
-Fixed the prison roof having incorrect magic blue

Credits
-------

If you enjoy TTRS-v3, think of the artists and coder who made that possible.
The set was drawn by Zimmlock (most of the graphics), George, the Tycoonez.com:munity, Oz, Red*Star,
Purno and Pikkabird, and was coded by Csaboka.
TTRS-v3 has been made for the Transport Tycoon fans; you are free to use it at your disposal,
as long as you give the right credits. That includes modifications and enhangements to individual
drawings and code slices.

Enjoy, Best Regards
the TTRS-v3 team.
