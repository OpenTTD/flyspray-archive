GENERIC BUFFER-STOPS V0.1
GRAPHICS BY CHRISTOPHER JONES AKA BORN_ACORN
CODAGE BY PETER NELSON AKA PETER1138

INSTALLATION TTDPATCH

Place the buffers.grf file into your /newgrf/ directory, and add /newgrf/buffers.grf to your newgrf.cfg
Make sure the GRF is below any bridge sets, for compatibility.

INSTALLATION OPENTTD

PRE 0.5.0
Place the buffers.grf file into your /data/ directory, and add [newgrf] to the end of openttd.cfg, if it is not there. Then below that add the filename.

POST 0.5.0
Place the buffers.grf into /data/ or a subfolder of /data/ then add it ingame using the NewGRF Settings Window.

Enjoy!