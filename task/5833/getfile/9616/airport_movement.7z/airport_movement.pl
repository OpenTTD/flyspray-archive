#!/usr/local/ActivePerl-5.6/bin/perl -w
use strict;
use warnings;

my $meta_no     = 1;   # Is Corel Draw layer number in header, has to be sequential to display layers
my $path_new    = '../../trunkHG/src/table/airport_movement.h';  # Changed file path.
my $path_org    = '../../trunk/src/table/airport_movement.h';    # Unchanged file path.
my $path_out    = 'airport_movement.svg';                        # SVG output file path.
my $path_jav    = 'array.es';                                    # Javascript array file path.

open FILEin,       $path_new    or die $!;
my @file = <FILEin>;
close FILEin;

open FILEout, ">$path_out" or die $!;
print FILEout header();
print FILEout script();
open SCRIPTout, ">$path_jav" or die $!;
print SCRIPTout javaScriptArray('AirportMovingData', ' _air');
print SCRIPTout javaScriptArray('AirportFTAbuildup', ' _airport_fta_');
close SCRIPTout;
print FILEout csstyle();
print FILEout AirportDrawings();
print FILEout AirportMovingDataPoints ('');

open FILEin,    $path_org    or die $!;
@file = <FILEin>;
close FILEin;

print FILEout AirportMovingDataPoints ('_old');
print FILEout footer();

close FILEout;

#----------------------------------------------------------------------------------------------------------------
sub CleanString {

    my $line = shift;

    chomp ($line);
    $line =~ s/\r$//;
    $line =~ s/\/.+//g;                            # Kill comments
    $line =~ s{^\s+|\s+$|\t| }{}g;                 # Clean whitespace.
    return if $line eq '';                         #
    $line =~ s/AMD\(/\(/g;                         # substitute to (.
    $line =~ s/\),\(|\},\{/\t/g;                   # Substitute inner brackets for delimiter;
    $line =~ s/\),|\(|\},|\{//g;                   # Clean rest of brackets;
    return split(/\t/, $line);
}

#----------------------------------------------------------------------------------------------------------------
sub javaScriptArray {

my $in_block   = 0;
my $fieldCnt   = 0;
my $substring  = '';
my $outstring  = '';
my $name       = shift;
my $identifier = shift;

    foreach my $line (@file) {
        if ( $line =~ m/$name$identifier/ ) {
            $in_block = 1;
            $substring = '';    # really empty
            next;
        }

        if ( $line =~ /\};|MAX_ELEMENTS/ && $in_block) {
            $in_block = 0;
            $substring =~ s/\s+$//g;    # clean whitespace at end of string.
            chop $substring;            # take last comma away, crashes firefox  ], ]; => ]];
            $outstring .= $name . '[' . $fieldCnt . '] = [' . "\n" . $substring .'];' . "\n\n";
            $fieldCnt++;
        }

        if ( $in_block ) {
            my @Arr = &CleanString($line);
            if (!@Arr) {next;}
            $substring .= "\t";
            foreach (@Arr) {
                my @t4 = split(/,/, $_);
                $substring .= qq!\[$t4[0],$t4[1],"$t4[2]","$t4[3]"\], ! if $name eq 'AirportMovingData';
                $substring .= qq!\[$t4[0],"$t4[1]","$t4[2]",$t4[3]\], ! if $name eq 'AirportFTAbuildup';
            }
            $substring .= "\n";
        }
    }
    return $outstring;
}

#----------------------------------------------------------------------------------------------------------------
sub AirportMovingDataPoints {
    my $in_block    = 0;
    my $fieldCnt    = 0;
    my $dummy_id    = 0;    # Number for dummy field ID's
    my $dup_key     = 0;
    my %hash        = ();   # Used for duplicate key checking
    my $outstring   = '';
    my @local       = @file;
    my $regex       = 'AirportMovingData _airport';
    my $oldnew      = shift;

    foreach my $line (@file) {
        chomp ($line);

        if ($line =~ m/$regex/ ) {
            $in_block = 1;
            $line =~ s/\[.*//;              # Clean after '['.
            $line =~ /_/;
            $outstring .= qq! <g id="$'$oldnew" visibility="hidden">\n! . q!  <metadata id="CorelCorpID_! . $meta_no++ . qq!Corel-Layer"/>\n!;
            next;
        }
        if ($line =~ /\}\;/ && $in_block) {          # Stop at ");
            $outstring .= " </g>\n";
            $in_block = 0;
            $fieldCnt++;
            next;
        }
        if ($line =~ m/AMD\(/ && $in_block) {
            my @arr = split(/,|\(|\//, $line);
            s{\&|\#}{ }g        foreach @arr;  # Clean none friendly characters & and #.
            $arr[7] =~ s/\-/ /g if $arr[7];
            s/ +/ /g            foreach @arr;  # match at least 2 spaces, replace with a single space.
            s{^\s+|\s+$}{}g     foreach @arr;  # clean whitespace.
            s/ /_/g             foreach @arr;  # match 1 spaces, replace with "_".
            s/^\_|_$//g         foreach @arr;  # take _ from front and back.

            my $key = $arr[7];       # Format keys and rename dupplicate keys e.g. ID's
            if (!defined $key || $key eq '') {
                $key .= sprintf("%02d", $dummy_id++) . '_dummykey';
            }
            $key = sprintf("%02d", $fieldCnt) . '_' . $key; #Now we can find parent array when clickingon the screen.
            if (exists $hash{$key}) {
              $key .= '_dk' . sprintf("%02d", $dup_key++);
            }
            $hash{ $key } = '';

            my @colArr = split(/,/, $line);
            my $fill = '';
            my $stroke = '';
            my $s0 = '';
            my $f1 = '';
            ($s0,$f1) = split(/\|/, $colArr[2]);
            $s0 =~ s{^\s+|\s+$}{}g if ($s0);                  # clean whitespace.
            $f1 =~ s{^\s+|\s+$}{}g if ($f1);                  # clean whitespace.


            if (!$s0) {
                if (!defined $s0) {
                    $stroke = 'N';  #Null
                } else {
                    $stroke = '0';
                };
            } else {
                if ($s0 =~ m/AMED_NOSPDCLAMP/) { $stroke = '1'}
                if ($s0 =~ m/AMED_TAKEOFF/)    { $stroke = '2'}
                if ($s0 =~ m/AMED_SLOWTURN/)   { $stroke = '3'}
                if ($s0 =~ m/AMED_LAND/)       { $stroke = '4'}
                if ($s0 =~ m/AMED_EXACTPOS/)   { $stroke = '5'}
                if ($s0 =~ m/AMED_BRAKE/)      { $stroke = '6'}
                if ($s0 =~ m/AMED_HELI_RAISE/) { $stroke = '7'}
                if ($s0 =~ m/AMED_HELI_LOWER/) { $stroke = '8'}
                if ($s0 =~ m/AMED_HOLD/)       { $stroke = '9'}
            }
            if (!$f1) {
                if (!defined $f1) {
                    $fill = 'N';
                } else {
                    $fill = '0';
                };
            } else {
                if ($f1 =~ m/AMED_NOSPDCLAMP/) { $fill = '1'}
                if ($f1 =~ m/AMED_TAKEOFF/)    { $fill = '2'}
                if ($f1 =~ m/AMED_SLOWTURN/)   { $fill = '3'}
                if ($f1 =~ m/AMED_LAND/)       { $fill = '4'}
                if ($f1 =~ m/AMED_EXACTPOS/)   { $fill = '5'}
                if ($f1 =~ m/AMED_BRAKE/)      { $fill = '6'}
                if ($f1 =~ m/AMED_HELI_RAISE/) { $fill = '7'}
                if ($f1 =~ m/AMED_HELI_LOWER/) { $fill = '8'}
                if ($f1 =~ m/AMED_HOLD/)       { $fill = '9'}
            }

            my $class = "fCi$fill sCi$stroke";

            # Att -1 added to come back to correct reading used for flipping drawing on horizontal axis.
            if ($oldnew =~ m/_old/) { 
                $outstring .= '  <circle class="' . $class . '" cx="' . $arr[1] * -1 . '" cy="' . $arr[2] * 1 . '" r="3"/>' . "\n";
            } else {
                $outstring .= '  <circle id="' . $key . '" class="' . $class . '" cx="' . $arr[1] * -1 . '" cy="' . $arr[2] * 1 . '" r="3"/>' . "\n";
            }

            next;
        }
    }
    return $outstring;
}

#----------------------------------------------------------------------------------------------------------------
sub header {

return <<"ENDOFTEXT";<?xml version="1.0" encoding="UTF-16"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="1000mm" height="800mm" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
viewBox="-600 -300 1000 800"
 xmlns:xlink="http://www.w3.org/1999/xlink" onload="init(evt);">
<script type="application/ecmascript"> <![CDATA[
ENDOFTEXT
}

#----------------------------------------------------------------------------------------------------------------
sub script {
return <<"ENDOFTEXT";
var svgDoc, pageWidth, pageHeight, offsetx, offsety, invX, invY, activeCircle, airports, AirportMovingData, AirportFTAbuildup;

airports = ['dummy', 'country', 'commuter', 'city', 'metropolitan', 'international', 'intercontinental', 'heliport', 'helidepot', 'helistation', 'oilrig'];
AirportMovingData = [];
AirportFTAbuildup = [];

function show(id) {
    'use strict';

    svgDoc.getElementById(id).setAttributeNS(null, 'visibility', 'visible');
}
function hide(id) {
    'use strict';

    svgDoc.getElementById(id).setAttributeNS(null, 'visibility', 'hidden');
}

function getArrayLocation(circle) {
    'use strict';

    var arrLoc, id;

    id = circle.getAttributeNS(null, 'id');
    id = id.replace(new RegExp('_', 'g'), ' '); // clean '_' character, in names.

    arrLoc = id.split(" ");              // Extract airfield arraynr and position for [0] and [1]
    arrLoc[0] = parseInt(arrLoc[0], 10); // Array position airport in Movement Positions array
    arrLoc[1] = parseInt(arrLoc[1], 10); // Position in Movement Positions array == First element of FTA "terminals array" (example 15) in FTA { 15, 0, NOTHING_block, 16 },.
    arrLoc[2] = id;                      // [2] used for cleaned string

    return arrLoc;
}

function logToConsole() {
    'use strict';

    var i, nr, arrLoc;

    if (!activeCircle) return;

    arrLoc = getArrayLocation(activeCircle);

    console.log('AMD = \\[' + arrLoc[0] + ', ' + arrLoc[1] + '\\], value = \\[' + AirportMovingData[arrLoc[0]][arrLoc[1]] + '\\]');

    for (i = 0; i < AirportFTAbuildup[arrLoc[0]].length; i++) {
        nr = AirportFTAbuildup[arrLoc[0]][i][0];
        if (nr === arrLoc[1]) {
            console.log(' - FTA ,\\[' + AirportFTAbuildup[arrLoc[0]][i] + "\\]\\n");
        }
    }
}

function showAssociations(cx, cy) {
    'use strict';

    var count, arrLoc, i, nr, line;

    if (!activeCircle) { return; }

    count = 0;
    arrLoc = getArrayLocation(activeCircle);

    // iterate through airport FTA to get assoiated points and draw respective lines.
    for (i = 0; i < AirportFTAbuildup[arrLoc[0]].length; i++) {
        nr = AirportFTAbuildup[arrLoc[0]][i][0];
        if (nr === arrLoc[1]) {
            nr = AirportFTAbuildup[arrLoc[0]][i][3]; // (example 16) in FTA { 15, 0, NOTHING_block, 16 }
            line = svgDoc.getElementById('as' + count++);

            line.setAttributeNS(null, "x1", cx);
            line.setAttributeNS(null, "y1", cy);
            line.setAttributeNS(null, "x2", invX * AirportMovingData[arrLoc[0]][nr][0]); // retreive x pos in Movement Positions array
            line.setAttributeNS(null, "y2", invY * AirportMovingData[arrLoc[0]][nr][1]); // retreive y pos in Movement Positions array
        }
    }
}

function hideAssociations() {
    'use strict';

    var dad, lines, i;

    dad = svgDoc.getElementById('associations');
    lines = dad.getElementsByTagName('line');

    for (i = 0; i < lines.length; i++) {
        lines[i].setAttributeNS(null, "x1", -50);
        lines[i].setAttributeNS(null, "y1", 600);
        lines[i].setAttributeNS(null, "x2", 170);
        lines[i].setAttributeNS(null, "y2", 600);
    }
}

function showTooltip(evt) {
    'use strict';

    var tooltip, arrLoc, cx, cy;

    activeCircle = evt.target;

    cx = activeCircle.getAttributeNS(null, 'cx');
    cy = activeCircle.getAttributeNS(null, 'cy');
    arrLoc = getArrayLocation(activeCircle);

    tooltip = svgDoc.getElementById('tooltip');
    tooltip.setAttributeNS(null, 'x', cx - 100);
    tooltip.setAttributeNS(null, 'y', cy - 10);
    tooltip.firstChild.data = arrLoc[2] + ' (' + cx * invX + ', ' + cy * invY + ')'; // Att -1 added to come back to correct reading used for flipping drawing vertical.
    show('tooltip');
    showAssociations(cx, cy);
}

function hideTooltip() {
    'use strict';

    hide('tooltip');
    hideAssociations();
}

function showHideFieldOld(evt) {
    'use strict';

    var showOldDots, i;

    showOldDots = false;
    if (svgDoc.getElementById('_old').getAttributeNS(null, 'class') ===  'fBu1 sBu0') {
        showOldDots = true;
    }
    for (i = 0; i < airports.length; i += 1) {
        if (showOldDots) {
            if (svgDoc.getElementById(airports[i]).getAttributeNS(null, 'class') ===  'fBu1 sBu0'){
                show('airport_moving_data_' + airports[i] + '_old');
            } else {
                hide('airport_moving_data_' + airports[i] + '_old');
            }
        } else {
            hide('airport_moving_data_' + airports[i] + '_old');
        }
    }
}

function clickOldNew(evt) {
    'use strict';

    var button = svgDoc.getElementById('_old');
    if (button.getAttributeNS(null, 'class') ===  'fBu1 sBu0') {
        button.setAttributeNS(null, 'class', 'fBu0 sBu0');
    } else {
        button.setAttributeNS(null, 'class', 'fBu1 sBu0');
    }
    showHideFieldOld();
}

function showHideField(evt) {
    'use strict';

    var button, buttonOld;

    button    = evt.target;
    buttonOld = svgDoc.getElementById('_old');

    if (button.getAttributeNS(null, 'class') ===  'fBu1 sBu0') {
        button.setAttributeNS(null, 'class', 'fBu0 sBu0');
        hide('airport_moving_data_' + button.id);
        hide(button.id + '_field');
    } else {
        button.setAttributeNS(null, 'class', 'fBu1 sBu0');
        show('airport_moving_data_' + button.id);
        show(button.id + '_field');
    }
    showHideFieldOld();
}

function movePoint(xm, ym) {
    'use strict';

    var x, y, arrLoc;

    if (!activeCircle) { return; }

    x = parseInt(activeCircle.getAttributeNS(null, 'cx'), 10);
    y = parseInt(activeCircle.getAttributeNS(null, 'cy'), 10);

    arrLoc = getArrayLocation(activeCircle);

    AirportMovingData[arrLoc[0]][arrLoc[1]][0] = (x + xm) * invX;
    AirportMovingData[arrLoc[0]][arrLoc[1]][1] = (y + ym) * invY;

    activeCircle.setAttributeNS(null, 'cx', x + xm);
    activeCircle.setAttributeNS(null, 'cy', y + ym);

    showAssociations(x + xm, y + ym);
}

function keyBoardEvents(evt) {
    'use strict';

    var cKey;

    cKey = {  a : 65, b : 66, c : 67, d : 68, g : 71, h : 72, s : 83, w : 87 };

    switch (evt.keyCode) {
    case cKey.b:
        if (svgDoc.getElementById('buttons').getAttributeNS(null, 'visibility') === 'visible') {
            hide('buttons');
        } else {
            show('buttons');
        }
        break;
    case cKey.c:
        logToConsole();
        break;
    case cKey.g:
        if (svgDoc.getElementById('grid').getAttributeNS(null, 'visibility') === 'visible') {
            hide('grid');
        } else {
            show('grid');
        }
        break;
    case cKey.h:
        if (svgDoc.getElementById('help').getAttributeNS(null, 'visibility') === 'visible') {
            hide('help');
        } else {
            show('help');
        }
        break;
    case cKey.w:
        movePoint(0, -1);  // Move active circle up.
        break;
    case cKey.s:
        movePoint(0, 1);  // Move active circle down.
        break;
    case cKey.a:
        movePoint(-1, 0);  // Move active circle left.
        break;
    case cKey.d:
        movePoint(1, 0);  // Move active circle right.
        break;
    }
}

function NewObj(objtype, props, dad, text) { //   Creates a new object with properties, and optionally appends to a parent element.
    'use strict';

    var el, a;

    el = svgDoc.createElementNS('http://www.w3.org/2000/svg', objtype);

    if (props) {
        for (a in props) {
            if (props.hasOwnProperty(a)) {
                el.setAttributeNS(null, a, props[a]);
            }
        }
    }
    if (dad) {
        dad.appendChild(el);
    }
    if (text) {
        el.appendChild(svgDoc.createTextNode(text));
    }
    return el;
}

function drawGrid() {
    'use strict';

    var layer, size, fieldCnt, i, line;

    layer    = svgDoc.getElementById('grid');
    size     = 16; // Set grid spacing

    fieldCnt = 4; // horizontal lines
    for (i = 0; i < pageHeight; i += 1) {
        line = new NewObj('line', {class: 'fLin sGr0', x1 : offsetx, y1 : offsety + i, x2 : offsetx + pageWidth, y2 : offsety + i}, layer);
        if (fieldCnt === size) {
            line.setAttributeNS(null, 'class', 'fLin sGr1');
            fieldCnt = 0;
        }
        fieldCnt += 1;
    }
    fieldCnt = 8; // vertical lines
    for (i = 0; i < pageWidth; i += 1) {
        line = new NewObj('line', {class: 'fLin sGr0', x1 : offsetx + i, y1 : offsety, x2 : offsetx + i, y2 : offsety + pageHeight}, layer);
        if (fieldCnt === size) {
            line.setAttributeNS(null, 'class', 'fLin sGr1');
            fieldCnt = 0;
        }
        fieldCnt += 1;
    }
    show('grid');
}

function adEvents() {
    'use strict';

    var i, circles;

    circles = svgDoc.getElementsByTagName('circle');

    for (i = 0; i < circles.length; i += 1) {

        if (circles[i].id) {
            circles[i].addEventListener('mouseleave', hideTooltip, false);
            circles[i].addEventListener('mouseenter', showTooltip, false);
        }
    }
    for (i = 0; i < airports.length; i += 1) {
        svgDoc.getElementById(airports[i]).addEventListener('click', showHideField, false);
    }
    svgDoc.documentElement.addEventListener('keydown', keyBoardEvents, false);

}

function init(evt) {
    'use strict';

    var svg, box;

    svgDoc = evt.target.ownerDocument;

    svg = svgDoc.getElementsByTagName('svg')[0];
    pageWidth = parseInt(svg.getAttribute('width').replace(/[^0-9]+/g, ''), 10);
    pageHeight = parseInt(svg.getAttribute('height').replace(/[^0-9]+/g, ''), 10);
    box = svg.viewBox.baseVal;
    offsetx = box.x;
    offsety = box.y;
    invX = -1;  // Flip image y-axis see perl script.
    invY = 1; // Flip image x-axis see perl script.

    adEvents();
    drawGrid();
    show('airport_moving_data_intercontinental');
    show('intercontinental_field');
}

ENDOFTEXT
}


#----------------------------------------------------------------------------------------------------------------
sub csstyle {

return <<"ENDOFTEXT";
]]> </script>
 <script type="application/ecmascript" xlink:href="array.es"/> 

 <defs>
  <style type="text/css">
   <![CDATA[
    .sLin {stroke:#1F1A17;stroke-width:0.075}
    .sGr0 {stroke:#97AFA0;stroke-width:0.075}
    .sGr1 {stroke:#0093DD;stroke-width:0.075}
    .sAs0 {stroke:#28166F;stroke-width:0.7}
    .sCiN {stroke:#808080;stroke-width:1}
    .sCi0 {stroke:#FFFF00;stroke-width:1}
    .sCi1 {stroke:#00FF00;stroke-width:1}
    .sCi2 {stroke:#008000;stroke-width:1}
    .sCi3 {stroke:#00FFFF;stroke-width:1}
    .sCi4 {stroke:#FFA500;stroke-width:1}
    .sCi5 {stroke:#000000;stroke-width:1}
    .sCi6 {stroke:#FF0000;stroke-width:1}
    .sCi7 {stroke:#CD853F;stroke-width:1}
    .sCi8 {stroke:#FF1493;stroke-width:1}
    .sCi9 {stroke:#0000FF;stroke-width:1}
    .sC99 {stroke:#97AFA0;stroke-width:1}
    .sBu0 {stroke:#000000;stroke-width:1.2}
    .stxB {stroke:#000000;stroke-width:0.2}
    .stxH {stroke:#66CC00;stroke-width:0.8}
    .stxN {stroke:#000000;stroke-width:0.2}
    .fLin {fill:none}
    .fAP0 {fill:#DEDEDD}
    .fCiN {fill:#F8F8FF}
    .fCi0 {fill:#FFFF00}
    .fCi1 {fill:#00FF00}
    .fCi2 {fill:#008000}
    .fCi3 {fill:#00FFFF}
    .fCi4 {fill:#FFA500}
    .fCi5 {fill:#000000}
    .fCi6 {fill:#FF0000}
    .fCi7 {fill:#CD853F}
    .fCi8 {fill:#FF1493}
    .fCi9 {fill:#000000}
    .fC99 {fill:#FFFFFF}
    .fBu0 {fill:#F8F8FF}
    .fBu1 {fill:#FFA500}
    .ftxG {fill:#66CC00}
    .ftxO {fill:#FFA500}
    .fnt0 {font-weight:normal;font-size:0.35pt;font-family:'Arial'}
    .fnt1 {font-weight:normal;font-size:10pt;font-family:'Arial'}
    .fnt3 {font-weight:normal;font-size:7pt;font-family:'Arial'}
    .fnt4 {font-weight:normal;font-size:4pt;font-family:'Arial'}
   ]]>
ENDOFTEXT
}

#----------------------------------------------------------------------------------------------------------------
sub AirportDrawings {

return q!

  </style>
 </defs>
 
 <g id="dir">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
 </g>
 <g transform="translate(-160,0)">
 <g id="dummy_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fLin sLin" x="96" width="64" height="48"/>
 </g>
 <g id="country_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fLin sLin" x="96" width="64" height="48"/>
  <rect class="fAP0 sLin" x="96" y="32" width="64" height="16"/>
  <line class="fLin sCiN" x1="112" y1="0" x2="112" y2= "16" />
  <line class="fLin sCiN" x1="112" y1="0" x2="96" y2= "0" />
  <line class="fLin sCiN" x1="96" y1="0" x2="96" y2= "16" />
 </g>
 <g id="commuter_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fLin sLin" x="80" width="80" height="64"/>
  <rect class="fAP0 sLin" x="80" y="48" width="80" height="16"/>
  <line class="fLin sCiN" x1="96" y1="0" x2="96" y2= "16" />
  <line class="fLin sCiN" x1="96" y1="0" x2="80" y2= "0" />
  <line class="fLin sCiN" x1="80" y1="0" x2="80" y2= "16" />
 </g>
 <g id="city_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fLin sLin" x="64" width="96" height="96"/>
  <rect class="fAP0 sLin" x="64" y="80" width="96" height="16"/>
  <line class="fLin sCiN" x1="80" y1="0" x2="80" y2= "16" />
  <line class="fLin sCiN" x1="80" y1="0" x2="64" y2= "0" />
  <line class="fLin sCiN" x1="64" y1="0" x2="64" y2= "16" />
 </g>
 <g id="metropolitan_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fLin sLin" x="64" width="96" height="96"/>
  <rect class="fAP0 sLin" x="64" y="80" width="96" height="16"/>
  <rect class="fAP0 sLin" x="64" y="64" width="96" height="16"/>
  <line class="fLin sCiN" x1="80" y1="0" x2="80" y2= "16" />
  <line class="fLin sCiN" x1="80" y1="0" x2="64" y2= "0" />
  <line class="fLin sCiN" x1="64" y1="0" x2="64" y2= "16" />
 </g>
 <g id="international_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fLin sLin" x="48" width="112" height="112"/>
  <rect class="fAP0 sLin" x="48" y="96" width="112" height="16"/>
  <rect class="fAP0 sLin" x="48" width="112" height="16"/>
  <line class="fLin sCiN" x1="160" y1="48" x2="160" y2= "64" />
  <line class="fLin sCiN" x1="160" y1="48" x2="144" y2= "48" />
  <line class="fLin sCiN" x1="144" y1="48" x2="144" y2= "64" />
  <line class="fLin sCiN" x1="64" y1="16" x2="64" y2= "32" />
  <line class="fLin sCiN" x1="64" y1="16" x2="48" y2= "16" />
  <line class="fLin sCiN" x1="48" y1="16" x2="48" y2= "32" />
 </g>
 <g id="intercontinental_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <polygon class="fLin sLin" points="160,0 16,0 16,160 32,160 32,176 160,176 "/>
  <rect class="fAP0 sLin" x="32" y="160" width="128" height="16"/>
  <rect class="fAP0 sLin" x="16" width="128" height="16"/>
  <rect class="fAP0 sLin" x="32" y="16" width="128" height="16"/>
  <rect class="fAP0 sLin" x="16" y="144" width="128" height="16"/>
  <line class="fLin sCiN" x1="160" y1="80" x2="160" y2= "96" />
  <line class="fLin sCiN" x1="160" y1="80" x2="144" y2= "80" />
  <line class="fLin sCiN" x1="144" y1="80" x2="144" y2= "96" />
  <line class="fLin sCiN" x1="32" y1="64" x2="32" y2= "80" />
  <line class="fLin sCiN" x1="32" y1="64" x2="16" y2= "64" />
  <line class="fLin sCiN" x1="16" y1="64" x2="16" y2= "80" />
 </g>
 <g id="heliport_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fAP0 sLin" x="144" width="16" height="16"/>
 </g>
 <g id="helidepot_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fAP0 sLin" x="144" y="16" width="16" height="16"/>
  <rect class="fLin sLin" x="128" width="32" height="32"/>
  <line class="fLin sCiN" x1="144" y1="0" x2="144" y2= "16" />
  <line class="fLin sCiN" x1="144" y1="0" x2="128" y2= "0" />
  <line class="fLin sCiN" x1="128" y1="0" x2="128" y2= "16" />
 </g>
 <g id="helistation_field" visibility="hidden">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect class="fLin sLin" x="96" width="64" height="32"/>
  <rect class="fAP0 sLin" x="112" width="16" height="16"/>
  <rect class="fAP0 sLin" x="96" y="16" width="16" height="16"/>
  <rect class="fAP0 sLin" x="96" width="16" height="16"/>
  <line class="fLin sCiN" x1="160" y1="0" x2="160" y2= "16" />
  <line class="fLin sCiN" x1="160" y1="0" x2="144" y2= "0" />
  <line class="fLin sCiN" x1="144" y1="0" x2="144" y2= "16" />
 </g>
  <g id="oilrig_field" visibility="hidden">
  <metadata id="CorelCorpID_12Corel-Layer"/>
  <rect class="fLin sLin" x="128" y="0" width="32" height="48"/>
  <rect class="fAP0 sLin" x="128" y="0" width="16" height="16"/>
 </g>
 </g>
 <g id="grid" visibility="visible"> </g>
!;
}

#----------------------------------------------------------------------------------------------------------------
sub footer {

return q! <g id="associations">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <line id="as0" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as1" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as2" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as3" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as4" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as5" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as6" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as7" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as8" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as9" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as10" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as11" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as12" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as13" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as14" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as15" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as16" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as17" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as18" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as19" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
  <line id="as20" class="fLin sAs0" x1="-50" y1="600" x2="170" y2= "600" />
 </g>
 <g transform="translate(-580,-30)" id="buttons" visibility="visible">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <rect id="dummy" class="fBu0 sBu0" x="0" y="0" width="16" height="16"/><text x="32" y="16" class="ftxG stxB fnt1">dummy</text>
  <rect id="country" class="fBu0 sBu0" x="0" y="20" width="16" height="16"/><text x="32" y="36" class="ftxG stxB fnt1">country</text>
  <rect id="commuter" class="fBu0 sBu0" x="0" y="40" width="16" height="16"/><text x="32" y="56" class="ftxG stxB fnt1">commuter</text>
  <rect id="city" class="fBu0 sBu0" x="0" y="60" width="16" height="16"/><text x="32" y="76" class="ftxG stxB fnt1">city</text>
  <rect id="metropolitan" class="fBu0 sBu0" x="0" y="80" width="16" height="16"/><text x="32" y="96" class="ftxG stxB fnt1">metropolitan</text>
  <rect id="international" class="fBu0 sBu0" x="0" y="100" width="16" height="16"/><text x="32" y="116" class="ftxG stxB fnt1">international</text>
  <rect id="intercontinental" class="fBu1 sBu0" x="0" y="120" width="16" height="16"/><text x="32" y="136" class="ftxG stxB fnt1">intercontinental</text>
  <rect id="heliport" class="fBu0 sBu0" x="0" y="140" width="16" height="16"/><text x="32" y="156" class="ftxG stxB fnt1">heliport</text>
  <rect id="helidepot" class="fBu0 sBu0" x="0" y="160" width="16" height="16"/><text x="32" y="176" class="ftxG stxB fnt1">helidepot</text>
  <rect id="helistation" class="fBu0 sBu0" x="0" y="180" width="16" height="16"/><text x="32" y="196" class="ftxG stxB fnt1">helistation</text>
  <rect id="oilrig" class="fBu0 sBu0" x="0" y="200" width="16" height="16"/><text x="32" y="216" class="ftxG stxB fnt1">oilrig</text>
  <rect id="_old" class="fBu0 sBu0" x="440" y="0" width="16" height="16" onclick="clickOldNew()"/><text x="472" y="16" class="ftxG stxB fnt1">Show old points</text>
 </g>
 <g>
  <text x="320" y="390" id="tooltip" class="fil1 fnt3">tooltip don’t delete, by HackaLittleBit.;-)</text>
 </g>
 <g id="help" visibility="visible">
  <metadata id="CorelCorpID_! . $meta_no++ . q!Corel-Layer"/>
  <svg x="50" y="-235">
   <text x="45" y="20" class="ftxO stxH fnt1">Code colors</text>
   <ellipse class="fCiN sCiN" cx="15" cy="35" rx="10.5" ry="6.5"/><text x="45" y="40" class="ftxO stxN fnt1">null</text>
   <ellipse class="fCi0 sCi0" cx="15" cy="55" rx="10.5" ry="6.5"/><text x="45" y="60" class="ftxO stxN fnt1">0</text>
   <ellipse class="fCi1 sCi1" cx="15" cy="75" rx="10.5" ry="6.5"/><text x="45" y="80" class="ftxO stxN fnt1">AMED_NOSPDCLAMP</text>
   <ellipse class="fCi2 sCi2" cx="15" cy="95" rx="10.5" ry="6.5"/><text x="45" y="100" class="ftxO stxN fnt1">AMED_TAKEOFF</text>
   <ellipse class="fCi3 sCi3" cx="15" cy="115" rx="10.5" ry="6.5"/><text x="45" y="120" class="ftxO stxN fnt1">AMED_SLOWTURN</text>
   <ellipse class="fCi4 sCi4" cx="15" cy="135" rx="10.5" ry="6.5"/><text x="45" y="140" class="ftxO stxN fnt1">AMED_LAND</text>
   <ellipse class="fCi5 sCi5" cx="15" cy="155" rx="10.5" ry="6.5"/><text x="45" y="160" class="ftxO stxN fnt1">AMED_EXACTPOS</text>
   <ellipse class="fCi6 sCi6" cx="15" cy="175" rx="10.5" ry="6.5"/><text x="45" y="180" class="ftxO stxN fnt1">AMED_BRAKE</text>
   <ellipse class="fCi7 sCi7" cx="15" cy="195" rx="10.5" ry="6.5"/><text x="45" y="200" class="ftxO stxN fnt1">AMED_HELI_RAISE</text>
   <ellipse class="fCi8 sCi8" cx="15" cy="215" rx="10.5" ry="6.5"/><text x="45" y="220" class="ftxO stxN fnt1">AMED_HELI_LOWER</text>
   <ellipse class="fCi9 sCi9" cx="15" cy="235" rx="10.5" ry="6.5"/><text x="45" y="240" class="ftxO stxN fnt1">AMED_HOLD</text>
  </svg>
  <svg x="-350" y="-235">
  <text y="20">
   <tspan x="0" class="ftxO stxH fnt1">Keyboard:</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">h = Help show-hide.</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">Ctrl + (mouseScroll or +/-) = Zoom in/out.</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">b = Buttons show-hide.</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">c = Show array values in browser logging console.(F12 with FF)</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">g = Grid show-hide.</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">After activating point with cursor:</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">w = Up</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">s = Down</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">a = Left</tspan>
   <tspan x="0" dy="20" class="ftxO stxN fnt1">d = Right</tspan>
  </text>
  </svg>
  <g>
   <text x="-200" y="-275" class="ftxO stxH fnt1">OpenTTD Airport Movement Layout</text>
  </g>
  <g>
   <image x="-580" y="-290" width="150" height="145" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAACRCAYAAAAhBEFaAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAABIAAAASABGyWs+AAAACXZwQWcAAACWAAAAkQC2t/MMAABXSElEQVR42u2dd5xkVZm/n3PvrRy6uqtz9+ScA5MY4giCgC5Ggu66a9hdA7vqroBK0N+quxI2GAkCooKgqJhBRckSh8k5MKFzqqquXHXvPb8/7q3qqurqme6ZAQahPtRnuqmudM9z3+/3vOc971V581btJgAFUD71qU/VLlmyJKSqquzs7FTs/y9K/u7NW5Wb+uYhqAqVAPjMZz4zb3Bw8IZDhw59OJPJ5KPR6P58Pl+ASdr3N+F6E6zxQ3XllVcu1HX9hqGhoXd2d/dMiUajp3g8nlgul3tZ1/UCVLwJ15tgjRcqcdVVV80DbkgmUxdoelz41Qyd/bFgJptdbprmoK7r+6WUJmC+GbneBGtcUF177bVzgRuTyeTbnDKlXLamgXcsb6CzL8aOgwP+XC63BIgYhrGvBKw3I9ebYI0tf1dfffUC4MZYLPY2TY8r71xewymTXIRcBvPaA3QPJdh5OBIwDHOxqqpxKeU+QH8TrjfBGjNSff7zn19omuYNqVTqfDU/rFy8JMCKSQ5kPok0coR8DhZMDtE1kGBP93BAShYrihIRQuyXUr4J15tgjYbqmmuumW+a5teSyeQFmplS3r28luXtKuSTYOoIJFJKarwOFk8P0z2YYm9XzG/CYkWIQTtyFTzXm3C9gcEqyt8111yzQNf1GyKR6AWaERfvOaWWpW1aGVQIgRAWJzU+J4um1tIbTbOnKxowDHMxMAzsBYw3I9cbF6wiVNdee+1iXddvjESi56n5qPLOpUFOaXfYUOWLUBWfKAQCqA24WDKtjq6hJHs6YwHTlAW49r/pud6YYJXO/pbk8/mbotHoW8lGlfedEmLVZCfkU3akogyqUrgAQn4XS6eH6RhIsKfL8lxABHhTFt9gYBWhuv7665foun7DUCTyVjUbFZesDHHKJAfCSIM0x4SqEq4an5PF08L0RjLs6Yr5bbhitiy+oeFS32BQ8cUvfnF5Lpe7YWgocq7LHOaSFSGWtTtQClCJI0NVKYt1fjeLp9XRF0uzpysWMCVLgBSwp8RzveGSqOobLFItzWazN0Wj0XVOIybeszzEskkOhF4C1QTGvhC5LM8VpnMwxb6umN+ULNE0LS6E2FeSinhDwaW+UaC67rrrFtmeap2Si4pLV9axtE1D6GnEMUBVCVfQ62T5zHr6Yxn2dA37QCxWFCUupdxbYujfMHCpbwCouPbaa5fpun7z0FDkLU4jJi5dWceSVrUIFccIVZksihHPFU3m2NkR9emGXAwyYcviGwou9a89Ul1//fXLc7nczZFodJ3LHBbvPSXEMjtScRyRaizPFfK7WDwtTH8sza7OqM8wzKVAwp4t5t8ocKl/zVBdc801S/L5/I3RaHSdlo9xiQ0Vxyl/45ktLp0epnsoxe7OqNc29MNvJEOv/rVCdd111y01DOOmoaHIOoceE5etrGVJiafiBENVCVfA62Dp9DBD8Rw7OyIFuBLA7jcCXOpfIVR88YtfPCWXy900NBQ5220Oi0tWhFjS+spDVSmLNT5LFiOJLDsPR32mlEuA9BvBc6l/hZFqeTabvSkSjZ7t0GPifStC1trfqwRVZeQK+ZwsmRamL5ZhV0fMZ0q5VFXVYUVR9v41pyLUvyaorr/++mX5fP6GSCSyTsvHuGxV3asaqY4oizPqGRzOsqsz5pFCLLFTEX+1kUv9K4GK66+/fkUul7thcGjoLR4zzqUra1k8gZRCLm8QSeboj6WJJXLE03mGU7myezydI53VQYCqKNabHyVLX5DFoNfB4ql1RFN5dnVEfbpu/FXLovbXEKm++MUvLs9kMjdGotGzPGac95xSw+JWddzyl8zk2ds1zK6OKJFEFoem4NCUUW+mKgpel0Z7vY+5k0J4XY5xRy4FmNIU4JpLlyFNyU+f2t+Q083P2H/yI6wF7MLNsN9SvgnWazj7y2azN0ai0bO0XJT3ra5jccv4odINk8MDSZ7e3sPPntrPgf4kiiKOGIkagi6ue/9Kzj9lMkgdpDzq+qIQAqSkNezlmsuWYZgmP3t6f1g35GewFqt/ZKck/irg0l7HUHHttdcuz+fzNw4ODZ3tMoa5dHUdiyYAVUECo4ksHQMJ9valOWvdW2lra8Mf8KNp6qhnC6Hw5KN/5NcvdHD2itl4RBrT0MelXSNw+fjCpctQFcEDT+4P5w3zM/YHvbcCpNLqiDfBejWguu6661Zmc7kbo5HImR4zzvtWhiYUqUoH2+fWqAu40DSNBQvmc8opp9DS0oTT6Rz194qi0Nexn8jBrZiKB2R2woZeQTKlKcAXLluOEPDAk0VZVIUQ90gpC7KYf73Cpb0OoRLXXXfdymw2+9/RaHStUx/mfasso05+4rM/h6ZQ43MR9DpRFIVQbYj29jba2tpwOLSqYPn9AaKqhlAdlu0+ltmilLTX+7jmsuUYpuRnT71cr5vyU6qqStM07zFNM/Z6hkt7PUGlqqr4whe+sNJe+1vrMeNcsrqOhc3KMUEFoAiBYvsjIcDpcOJ2u3G7XaiqWhUsVVVK6raObQJXgKulzsu1ly1HVRQeeGp/WDfkp2yA7i3589cdXNrrKFLxhS98YU0ul7txKBJZ6yfBpavrmNcoSuTv2AZZN0zyujGSHhCjc1Fj/X68eS4FaG/w8/lLlqKqgh8/sb8+mzM+jdV85J6S2eLrCi7l9SJ/119//ZpMJnNzxIbqkpUh5jcdP1QAppTopnxNxqyQ55rU6OfzlyzjPadNw6kp9cBngA8AtYAbcDDS6Ua8GbGOEyq326189rOfXZnNZm+KxWJr3Ga8GKlk/vihAjBNiWm+dkFACIEsyqKV53rgqX21uiE/bZN+z+tNFrWTPVJdddVVq7LZ7E1DQ5G1fhE/YfJXesvkDTI54xhGSZ5QuAqe63OXLkVTBfc/sS+c181PY62Q/KDkDU96uLSTGaovfelLa9Lp9M1DkciagJLgkhW1xw2VlFZ0MqUlgdFElkN9Cfpj6QkNkZQSq+HMiYVLAaY0BPjcJcsA+PET++pzuvkp62HxQynl0OsBLu1khMrtditXXXXV6nQ6fVMkElnjKchf07HJn5SSXN4kmc2TyRnE03liyRyprE5vJMWuzhidAylMU47LnEtAmgYYVkFosRObnYCXUpI3TNJZA8OUCGHNPjVV4HKoqEfI7Fv/30pFfP7SZZgSfvLEvjo7FWGapvnD10MqQjvZoPJ4POKzn/3sGnuL1qle4ly+uo65ZZ5q/LO9dM4glszSPZTiUH+Cw/0JuoeSdA2m6ImkGBzOksjkURWFgC+Ix+OpmmYoA8s0MXQd9CxCtUa2kH0wpWRoOMvuriidA0kMU6KpCg5VwefWmNwYYEqjH6dDtXZaI47ouT53yVIE8JOn9tfaqQgV+D4QPZnh0k4mqABx9dVXr02n0zcODUXWBJUE71sxcU+VN0xiyRw9kRQHe+PsOBxh/Z4BXu4ZJp2X6MJFc2Md9a2tTF1YT7C2kdqQn4ZwmCmTJ+NyuY4iWbBhVwc/fmQTp86tpy3sxe1QEQIGhjM8saWbHz+xl46BZBE46y5or/fz2fcuY+XsBhuDseFSgEkNfj5/6TI0TeG+x/eFsznjU/YM8c6TORWhnSxQhcNh5YorrliTSqVujkajq/wiwftWWCmF8cqflJJUVudgX4KtB4Z4flcfL+3rpyuSIxyuY/rCFUyfMonm9imEGxoJBgL4fD48Xi9utxuv12v97vGMKVVSSi56x8Ukkynueuwv3PnwNk6b18DbV0+ltc7Lrs4YP3t6P3v68ixfvpra2lrcHg+qqoCUvPDCi/z4yf2snNsGRg4p5Zhfq5ihb/Dx+UuWoQi499G9oWzeuMIG6W5gyD6GuZMJLu1kgMrn8ykf//jHV2cymRuj0egqzzGkFHTDZGA4w/ZDER7b3MVjmzsZSBhMmTqdd5y5iCnTZ9DS0kZdfZiaYBCfz4vH48HhcOJwaDgcDjRNQ1FUO7M+NljLVq5hzvyFvLxvL398+CH++MdHeOzO51gxs46A18W2gxFWnHo6Z6w7lylTp1IbCqFpGqqmEgzV8ZeHf0okI6hza0g9N65URFOth6vftxQp4d5H9wRzunmF/SffsyOXPJkil3oSyB+f+9zn1ubz+ZuGhoZODShJLp9gSiGRzrO7M8ZT23q4/7G9PLqlh7qmSZz9lnM5/ayzWbRkGbNnz2Hq1Cm0trbS0FBPKFRLIBDA6/XgdrtxuVw4HA5UVUVRRsCqBpiUEkVRqQnVsWDxElatXkVdfSNPb9jD0xv30tzWztsufAez58xl2rRpNDc3UVdXS20ohN+t8fAf/sSS6Q1MbvBhmjpiVNmNLPxXPFBIidelsWhqLemczrZDEbdhdbnRgZ2UFwu+5jf1tYTK4XCI66677rR0On1zJBJdHVSSXLqylnkNE4Nq08uDPPTiYe57bA/dCTj99DM4Y925LFy8lNmzZzF16hSam5upra3F5/PZEGlFiFRVtZdyrLuiKBWztDFSA4rA4XAQqq1j3oJFrFq1Cr/Pw+o1q1m8fCWtrS3U19fj8XhxOp04HA5qQrX87ncPU+PSOWVWkyWHNgvlxVcSIbENvkRI6x5wO1g6vY54KseOwzG3bsolgC6E2GVHLEqi1hsKLAGIUCik/Pu///upmUzm5mgsttpLnMtX2fI3Aai2HRzioRcP8/O/7McTauDc895mSdXcOUyfPp2WlhZCoZAte+URaax7ARxxlI4ziqIUwXQ4HNTVN7B02SlMmzmbUKiWYDCI2+3G4dCK7+lwONm5dSO7d+7ivJXTUGVupMMNEoG09jzKkkpl+2drPUfic2ksm15HNJlj++Go25QsUlVVF0LslFLmT4bIpb5G8ieuvPLKtblc7qZIJLImIBK8f3Udc8YRqSyzK8jlDXZ1Rvn9+g5+9vR+GprbOff8C1m4eClz5sxmypQphMN1eL3e4sBWStzR4DkSVNVeR1UUnM5CdYQbp9Np+zal+LeqphFPJPjdQw/xjlNn4ndIMHWKDZilDVdJlBIlgBUA9DpVlk6tJZ0z2N4RcxumXCiE0KWUhcj1msKlvtpQzZw5U/nXf/3X0zOZzE2RSGR1jZrkkpV1zB2n/AkhMKWkJ5Li0U1d/OixPYQaWjnn/AuZv3ARs2fPor29nZqaGpxO55gR6kRlyqsBVhrJqkVCU8/xh4cfYnZLkJnNPkw9Zx0cGyJZ9FlyJIrZjxd+V4CAW2XJlBCpnMH2wzFPLm8skVIawGsui+qrCdXkyZOVD37wg2em0+mbo9HoSh8JLls18TxVPJ3nhd39fP+RnWSFn3PfdiELFi1m1qxZtLa2EggEirJ3JBN+IpdiKgErhbn0/aUEj9vFHx55FDUf57T5zch8FlkG0UikEhVySMnj2HAtnVpLLJVjW4nnsuHKvVZwqa8WVNOnT1c++MEPnpnNZr8WiURW+Ccgf6W3nG6wr2uYB57cz0v7hzlr3ToWLzuF2bNn09bWit8fKErf0Qx4qbRaICj2AB8fYGP5tsLN6XKzc+sm9u3cwTlLJ+MUOpiGBZGsgEiWQyakLIPQmi2qLJ1aQzyts+1wzGWYchHWZoydr5Usqq8GVLNmzVL+9m//9uxsNnvD4NDQirAjzWWr6phdPzGopJT0xzI8tqWbnz69n7nzF7Lm9LOYO3cukya1EwwGcTgcZZ5mrHRBqWTlcxk6Dx2gp7uTYE3tuKE8HgDzmRQ/++VvuWDlNOo8Aoz86EhVaeBLAauQSr9TZcmUGjI5ky2HY4VUhAnseC1kUXuloZo2bZrygQ984KxUKnVTJBJdGnakuWRFiFn1THhBOaebdAwkeHJrF6rLz7KVq5g8ZSotLS1F+SuFqhpQYJUX5zJpdmzfwtNPPMH6jVs5/PJuUJz84L77aWhoOEoO6/giG8CseQvRXF52d0aZXhsGadq5q5HXFVKW5bXK8p5yJEUBEimhpcbJZy+agWGa/PCpQzXpnPkJ+wnfAwYKh/HVSKJqrzBU6t9+4G/PSKVSN0aj0aVBJcElK+uYVccxVSnEU3n2dMXY/PIQ85etYsq0GbS2NlNTY0Wqo/mpQgQ7tH8vt916C088/jjTmoLMn1pP+8wafvViN+lMBl3Xy/xZ5Wsc3LeTYE0ttfVNmKY54egmpaS+vo7Zc+bw9JYOzl/UUCiZsCNRxZjLkQoKSmCTJSeLsP9PY9DJ1W+fgWma/PCpjmBWNz9hP+FOe/nnVYFLe6Wgmjx5ckH+vjYUiSyvVVNctrqOmXWMO09VejNMSTSZZcO+AfI4mDtvHi0tLdTVhXG73WOCUBlp9uzYxjWf/xx+TefmT72bBZMCeEnzx2e28OsXOxmOxQjX1eHxeMaE88EHfsLzL7zEP3/ik5x6+hloDpcdNeS44fIHQsxftITnHrqfeFonIASmYZRFodIoJSuilLQTqCMRjOLsscHv4KoLp+NQ4K4nO2qyefPj9tPueLXgUl4JqBYsWKB8+MMfPjubzd44FIksr3emudyG6liL9PK6SW80ze6OKM0tLUyaMp36+nr8fh+apo0rWqWTcb759f+jziP4+lXv54yZHgLZToZ6DtI3MEg+r9PT00s6nTmiP0qls7zw4no+f9WV/N9NX2NooLcM4HHJpBAsWTCX3uE8B/sSKIpqRSZpIqVZLCQs3AtJUyFNK7JJactnIaE68riKSWuNk89eMI0Pn9GO26GEgE8A/ySEqAdcgJNXsIZeOdFQzZw5U33ve997tl2lsLRWTXHJihAzw/K4Kj9TWZ2eoRSH+pNMmzqZ+oZGgsEgTqdrXCkFVVXZs2cP27Zs4mPvPYuwEiU/dBAzEyeVTJJM5dB1ncHBIXK5o29CXbdyHp//4Dn8+bc/5/NX/jt7dmzBNM0iVEeDyzRN5i5aiuIOsKcrCkKxYbFBMc0RYEwTTNMGyX6s5HHMAoCGDaFEYNIccHDV26bw92tbcTuUoBDi46qqfkRV1fArDZdyouXvsssuOyudTt8QiUSWBO0F5RkT9VSyxE/YESCZyTE4nCGdlzRPmk4oVIPX6zliJUJlpBkYipHLZpne6MVIDIJuLacYhoFuGEgpyWazGLYkHUlWVSG5YNUMvvmxMxk+sInPX3U1O7dsLItYR4OrNlzPvNkzeHFPH7pUrC9uGqMhKo1KFRAV/tZ6TFoQyhHoGvwaV18whQ+f3orbqQak5GNCiI8IIepeSbiUEwVVXV2d8qEPfWid3UlveZ0jxQdW1zGjbhyRynKhxUGRyKIcFA6SaZjEklm8bgd1tSH8fj8ul2tUInJsGMDtcmAaOn3dHQg9Yw1YMRqM32ZIKTHyeYxUlIVNGv/390upyXZw7TXXsHv7FkxzfHC5XG4Wn7KKTfv7SeUkAlEiayaYsgwiWSl9JQBSGuFK7oo0aQpoXHneJD5yWjNuBzWGYXxCSvlPwCsmi8qJgGr69OnqFVdcsS6VSt0ciUSWhp0pLl1Zy4xq8idl2d0CyYKo8swU9oFEmihI0pk8IPB4rLW4Um91tJtpmsycNoX6xhZ+8ef1mPms5V2L7zER/yqR0gA9h5FNMzmk8dVL5+OIvcxXv/wVOg/uH5csClVl/vz5JPOC/b1xFEUt81Zl3smsBEmWRKYR70XBl9lQCiSKlDQHND53Xjt/v6YRtyaCwMeBf3yl4FKOF6q5c+eq73//+8+yi/QWh9Qkl62yZ38F+SsxtdKePRVDfRlEVc4+WxoKplYRori4O5F1PylNGlvauewDH+CBp/fxq2f3YeoGum5gGEZZ2mCcbBU/r2EYTKlz86X3zKV710vc9u1vMByLlME1FuyzZ8/GU9vElgODCFUdA6KKSFRyvKRp30v/tsJ/IQ2QJmGvyufe2saHTm3EpYkA8E/AR4ET7rmU44Fq/vz56qWXXnq2JX9DS8OOFO9fU8f0WhOppxDSKAJV7aBgjoZIlEBUesAUJD6XWkwbHEt2XAIXv/u9vPuS9/P/HtjKtx/exeH+BOlMnlzemFjQKmbDC1JtsKjNz79fMJ1HHv4dD//6l+Tz+SJcVQGTktqGZqZPm8aWg0PkDLtL4JGOhzkii0c2+Mbox6VJg1/lynNb+cfTmnA7RA3wMTtynVDPpR0rVPPmzVMuueSSdclU6uZoJLKo3pnm0pUhZtSayFwaYadIKrPHoiLxN+LVyxODoiIZ6NYEk8JeMtl8MR0w0cmllBKX18fH/+XThGrr+MH37uLhDT2cNifMYCI3fkglVhGeHBl0Yf//ty6o47m9g3z/e99j8dJlzJq3sBhZR+W5pETVNFauXM693/0L0ZxKg+rANHIlk5hqx6P8eFV7TB4hydoc0LjynBZM0+TuZweCKTvPJYS4Q0rZfyLyXMqxQLV48WL1ve9971tSqdSN0UhkUUhNctnKEDNrDcgmEVKvEo1GPFNlNKqcPgtZcfZJidepMCnsweeAnkP7ME3DtkZyQssrAvAFgnzwI//If3/9G8xa9VZ+uSXBbzf0kNMNe/uXNi5plSUzuIIn8jgEHzqjHTPWxQP3/4hEIo5hzzhHLS8JBU1zsHz1aaQNjUNRHaE6irO78UajkXSDWZwplh33MpUwENKk0afyuXOb+ftVYdwOERBC/LOqqv+kaVojVq+I44pc2kShmjZtmnrxxRevy2azXxsaiiwJO5JcvjLE9BrdilSmWRKDZPFEEiUXHRWSMdfAxBhnnlOF5hons1u87Nt/gGw2N2FfVIgaAA6Hk6UrVjN91hx2bN3Mn/7wB/YfOERLcyNut2sc5t20NqxKw/7OI99zWtjF5auauOMPj3D+BReyZOWpVn1WSdGfaRhEB3rYtWM7Tz/9F2r8HhShIOzXrLpeWDxk5dn24vE9ynoiFZn6sFflqnOacChwx/NDwazOP4JUhBC3Hm/k0iYC1aJFi9T3vOc9b0mlUjcMDQ0taXSluXR5DdNqdMilLFkoOfhjh+8S0EatfZUfmMKpokiTer+DU6bX8tNN++g69DItrS04TbPMb40XMABN06ipreOU1WuZt2gZ8egQHp8ft9tz1OUhaeiIfBoMoyiFhWdoQnLBwjp+tn4Hv/nVr5g1byHucD3peIyuzk52bt/CM08/zaatO5CpKOGgh0++fRmLmhyY8USxVFnKEptQcjyqgnIECGWF9Sgs/ahImv0qn13XgEMV3P7cUDCRMf9JSimAW4G+Y4VLmwBU2rve9a5zk8nkDdFodGFYS3Lp8iDTQzoylyyWcYgqHqCaZxp99h35uQoSr0PhjDn1/PTZLjZteImFS5fjcbtHFmLHmSgteJ1iUZ69QycQ8FvJz6PshDYNk66BGLsO9tDqNXCrJg5V4FAVNMXyfm0hJ29fFOa+xx9n3pxZDA5F2bh5K/0dB5BGjmUzm/mH0yezfPoKZjZ6ceUGMKOdxe1gsurxqBaN5Cg/JitP4Cp+q+CDJJJmn8qVZ1kVFrc9M+RL5OQ/2of9mOFSxwPVKaecor797W9/ayabvSEajS6sVRK8f2WAGTWGDZVZtcKxWnFaoXitrOy2tK67St134XdFQNCtcnggyV+2dbB27WmE6uomXClaWdlZmGUWyokrS5krb32dB/jLC5t44C/7eXbPAAcHUqRzlr9yKKAI60Ror3WztzvGH558Hn3wEIta3fzdW+bz8QsW8/ZlzaxoddIghlBih5CJftBzRzke5ujHK44lcuyarsqiwULCFUw8GixtdZHRJZu6M07dZKHN3nYbKskE6rnUo0G1YsUK9aKLLjo/k8ncEIlEFja7Urz/lADTg3nIp1CkMfqLVNlhUgZK8TFzzM0DstpBQeJQBLU+B794Zi8ef5AFi5bgdDqPqZ59rJr1aiXFpbcZs+aw7ty3MnveAvriOk/uifDI5k4e3zXEQNza3ezWBHVelTPmhLlgWTuXnDab8xY0MNWbwZvpRYl3Ycb7kOko6FnrWFTdTGGWH48qx0RUnKzVTu6Rx8yS416SYMXEq8HSFquh74aurDNvweUAtgGFBVTzeMAqVCmoF1988fmpVPqmaCw6v8Wd4vJT/EwN5CxPhVEiZyPmW5SBVLo3bkTfSx+TZeG9xAcU/758C1TY7yCezvHgE9tYsmQxTS3tZWuGE636HG9JcfGgaQ6CtXVMnT6TlaeexprVq5g2ex5p6eDP2/t4aGM36w/GyBsmdR5BW0DBYyYh1Y9MRSCXtNYpTaPEN40cLznKf44+HqLSM1UcdykLAaYAp1kS8Uw7HWSf3BTqwEx8GixpdqCbkk09OWfeYBGgCSF2AJnxwqWOBdXq1au1QqSKxaLzmhwJLl/uZ4o/a8ufMVrOjlRKW/JFJbLqc0XJvroxz0wkmoCp9R6e2HKYbfs6WL1mNb5A8KiR5oTebJ/mcrmoq29k5uy5LF+5mrWnraWppZUDAxl+/eIhntjRTyqdo8UHfsdIBCqFRJYdL7OKlahyPAqvg1kC0Ug5jaBkqads6araY6X/38StwdIWBzldsqkn78hLsVBTVUVRlB2maY5LFtVqUJ111lnaOeecc34mm/1aJBJd0OxK8v7lXib7s8XZ35hyN2ov3IjccRQPUA2iyvBeeK2AS2Vy2M2PH9vGcDLLkqXLcLrdrxpcBW9mbVbVcDodeH1+wvWNzJm/iNWnnsqiRYuIZODhjYd5dFs3TlXQEnTgVkXZDpwjWYnqgI1EImRJFKoAhRKABKMhouSx0tcW0sStSpY2aYBkU6/pzJlioRCoUsrt45FFtRKqc845RzvzjDPelk6nb4xGo/Nb3UkuX+pmij+HsCOVKJn2irJKxmo6T4kRpQTCseWudMlElEyPR17fktzJdS4a/Rq3//IZkuk0i5csweXxlkH1Sm2GqGb+VVXB4dBwuZwEgjW0T5nGqrWns2TxYvriWe57cg9bDkWYWuek0aeilJ2UlcejHKLCgBdNfAEiSqJNyWOF32WJ1JVKYqkMlsvlCKReh2Rps4ppwqZe3ZnJy0VSSgfWBo0jyqJaCtV5552nnXLKKW9LpdM3xGKxuc3OJJcv9TDFl4Fc0n7DEYhkSeQarfMVnmlUpLKz8GXRilH76sp2CFcaW2BOs5ewV+HOX/2FwcEI8+bPwx+sKVs+eaUiVzVPVrnt3u1209I+iZVrTmPmrJk8vfUgv3h2H2GvwoywE02MfM+R1pOjISpaiUIGvQQAS05LMvPIsp+LWffSiFUR6WQVSRRIvJpkeYtCJm+yscdw5k3Lc9lwZceSRbWQYjr//PO1KVOmvC2dTv9XNBqd3+pK8YFlpVAZVp31EVICY++FMysAqjJ7kWOlGxg9UywcPPsAzm/xMaXWwb0PPcsLG7YybcpkGpubUSryUa+076q67V5V0TQNt9vNpKnTOXXtWgZjKe58aD0OYbK4xY0mCiUu1X1R5eytEi5KHiuTyyoAlc4Mi7/LkihXIqMFqXSrJkubFAxTsqHHdNizRdVORWSLBq8kv1WMWE1NTW26rt+SSCaXTA/k+PuVPqb6s8VIVfQ4HNlYl01rj5puqITIHDPdMMqblc0UJbMaPKycFmT91n3c8+DvyaQStLa2EAzVlQH1asA11s5oVVUJhGpZtmIlHpeL23/zHFLPsazNjYZV3jICUYlclYBWKVllclgabar4rdLKUjHqsbH9FlLi0UwW1gt0Ezb1SmfeZAFw2I5cJtYGWXMUWKFQqEnX9X8cjsdrpwZ03jLDhVvkwNBHlmeKcjXie+Qo812aUqAoWSPmm7JeBOW9CiiJZIzO05RkmkceG3lOS9DJunn1+JQ89/zqUf7wp8fJZ5KEw3UEa0IIu5Du1Yas0ou53G7mLVxCwOfi9l/9Bb9qsKTFZZcZGSNySEkkokQOKZE5KuRwjMdKfZkYQ25lFc9W+Fk3TPKGZF9U8uRhSc5AAOuBTVhb+vXSqFUASwkGg7qmac5EIrl0V8eQJ55Is6DFg9dBiVYXPJFZZcZClWhkVsmgm1XSDWaVZJ9ZNSpWSmnhvaSUmIaBS5EsmRTgLfPqySRiPPDbP/Pbh/9IX08PtTU+akK1OJxOC9EJLAWdSMCEEGgOB7PnL0KRBnf96ikWNDmZWqOAqY94qrJIM7bfKgOlilxWSqIsST2USmKpZyuNlHlDMpQx+cl2k/95QTKQRgJPAT8GBm05zFeCJQBlaGhIAjuFEHo8kT5l44EhVzyVZVGbF69DjIJkdP8ms4rxHp2OqJ5u4KjZ5Eojb5iSbN4gkzdIZnX6h3MMxHMkMnkUqdPo1zhtZohz5tXjMtM89uQz3P/g79i+ZRNmPk9N0IcvUGMtYBfBemWvmls5mVAdDmbPnce+lw/wu6c3s26Gl6CjXBLL/VJ171SWo6r2WAlclSmISohKc2RgkjNgIA0/3iG56XnoTADwOPAdYD/W5YczY4EFIBKJhJ7JZPZIKfOpTG7JpoMxdzKTZ0m7D79TGWmjU5YBlhXFfLKsumGUZEmobM1TvasKJf7Leo5uSIbTOr3DOXqGc7w8mGFrV4r1h5I8sXeYBzcN8fNNQ8QzBnPqHXgUnTqXZOVUP+cvaGBeo5OdO/fwi988xO9+/2cO7t2Jy+nE63bh8fnLmoK80jPJws3t8TJ92lR+8fDjpOMRTp3sREgdaZqj5JBR2fLRUlkqhzC2jFJNKgvH3+qpS84U9KcsqG5+HrqTmHakug3rWtZJIGVHrFEeq/QICl3X87qu7xYgdcNcsLUj4UlldZa0+/A5lTII5BiLydWTm2bVRKAcZc4ZFfWkNIkk8+zqTfPS4STPvBzn9zti/HbrEH/cOcwfdifYNgi6qxatbjJP7exjSkhlYbMbaeQhn8OnGsxucHHe/DBnzqrFYyZ48aVN/ORnv+CJJ57g5b278Xvc1De1vOJNQSpftzbcgDCy/Oi3T3D6VDdNXmk1CSlLiJYbbyFLMu5l0agclvJoVAqiLKsyKc1mFqDqs6H6nxegx4LqL8AtNlQJ+562o5VR+kqiNI9lr2Y7ALeqqmFNVT9iSvkJlyaCf7e6kSvPn0RTwFEc/MoyjLGK9SbU7KJo8Ed+Hs4a/HFnjPvWD7GrL0PaEHjcbrx1zUxpa6K9vY2m9mmE68OEQrX84if3Yhx6idsun0VIzViVnoVSFKEgNA1UF7G8yu6+FH/e3scjO4aIeKfy458+QGNj4wlv0nak2i6Awd4u/vlDH+TswCE+f6YfMrHiWmJJtVpZVz9GKUVpMWWVq5nJKussFSZAAjnDilT3j0AF8KQtf/uwrl0dtyPWKH811lqh3SZA5oCdiqLk8qZcurUr6Ypn8iybZMviGOkGUZH0PPJ6IuWpCMqrGwQSU0q6ojlufbqfzQMwb+FiVp15DmeevY6z3nIOK9aewYIly5k1ew5Tp01n0pTJtDU18sBvHmFqSGVeo7WX0PIt9oZQIwd6BrfM0u6XrJ7kIuCQPLQny4XveAfBYLCsG18lCKUtJ0+UL/MFAmTTKX7zh8c4b26QoJpD6tlyySoz5rJqhBIls+/qq8DVi40LhYVZUzBgQ/XfL0BvsmjUb7UjVfxoUB2pusG0jqHMSSl3q6qa1w0WbutKeeLpPEvbvAScStEDyRJQyqsXZFl0E6OWL2SxwUVl5CscHCklPcN5Ht0TR/rqOf+dl7B85Wrmzl/IlKlTaW1tpbm5ifr6ekKhEIFAgNa2dg4dfJknn9/AuXOC+FTDLvctHRADzDxSzxNPZ9ndl+HPh+GMs9YRDluNRqqBJYQgOjhAJhkv+rKRaCiO3dArCkGviwd/8wemB3Xm1YuSCpIx0gylJ6gYLWlHAqnKmjpZU9CXtCPVi9CbxACeA24HdldAlalMMYy3HsvukiPzUspdqqoauikXbe1KuWPpPEvaPBZc45gJliZGxajqBrNq17riwrWUpHMGB4dybOk3ecv5FzJnzmxaWlqorbVA8ng8xXbXqqridLloa2nm/gcfosWTZ3GLy+rzWWU13/JvBlt6sjzRASvXrKW1tQWfz1cRmUZAuOPrN/LN//1fBvr7qQ36qKmtR9G048uRSYm/JsRTjz9KPtLFGVNdKLm4tXGiLBqNARDjh2iU/JUY9ft3SP7PggrgIFb7o702UMMlkUo/0iK0MhZQ9pPyQMY0zUFd1+8SQnwrZ8joPc8P8J8Pd9IdzVbsxjFGb6iU1TZUGlV34yArN1tafxdyw6ywg3Q6g5FN4fV68Xo9xab/mqaNavw/e8FiLnrH33DHs4N0xk0UAdLU7ffWEabdntE0yOo6mbyBaUoymTS6rh8xwiSTKQ4e2M8jP/sBH/3QP/D1r32Zjn27ymCa0M6hYg2+gyXzZ7G5O0fG1ECoJbvGS0ZmggBNBKr/HfFUqKoa1jRtnrA+YNauJM1XQCUnsv2rEq6saZpD+Xz+B7W1tfcIh0u/98VBvvJ7C67SvgLSHGnDU9k1haqtd0agpKxPgSVfQhq4FUlzQMEv0nQf3INhWtfbGqtfe6EY7/K//xB6aCq3/aWfvAQFE6RunwAWYEgd0zDs15Tj2k4mgbVzW7nzE2fyb6udPPGz7/LJf/wwj/3+N+j53LibglTCpTk0Zi1bS2dcklG94HAf1Rsd86y0RP56k3Dvdsl/Pw+9GWhe5qd9TRChEZRSXqqq6gVCCFeVCR8TiVhjwvXOd74zfNZZZ82eMnmyiqJx3/oIX/1jN52RXHGr99h7A0shMyp29Rp29LAH3bQjSuFnqVPnhlqXSWfPANlsDsM48vZ1KSVtU6bxkY/8Az/fnuaxfWkUgb1lX0dK3e7sYox0bpmAbBn5DGER5wMLBD94l4/l6h4+9+//xq9/ci/5XDlc4wdMUFsXRlE1ktKDKID1ytQpFqH64TbJ/zwPfWloWR5g8d81sewjLUw5uwZFI4TkI5qmvUtRlADWfsOjXp96vPum5Ec/+tGp9fX1X0in0ue661Ux461hlIDKfesj/NcjPXQVZHGs/k3mCECWdBolEBnFQbbkz7A3ZerFqFXrhlq34HBXL6l4DMPQx262UWx9LTj3wr/h9HXncfPjQxyIGShCFiUQqdtLKEZFiuRog2Ji5HOYqSFkop92V4Ivn6Xx7vYh/ufmm9nw7BPH1g8C8Lo0PC4HCV0F5cT2Hi7tDpWzjfq92yTfeBH609C2OsiiyxsJtrsItDk55Z9bmXFhLUIjJE15haqq7xdCBBnHxc+Vo22mAPj4xz8+S9O0/4pFYxcmxJAy5b0ayz5Rz+IPNiECGvesj/LVR/rojGZL/JRhRSTTGBWFMHV7UEsesyUKU0eauhVF7MF3CIOAw6S9RmWocz/RgT70o/SwKlyp1FdTxxX/diX5+jn855+jDOekNdMyRyTRyheZExsge8OqMHPIfA6vyPCxZZJGo5fv3303kYG+o0bVMWXEvjTKiW64WCl/92yzjHp/FtrWBFlwaSPByW4cPhWHT6VmkouVn2xj9sV1CI2wNOW/aJr2YUVRCn0exoRLORpUn/70p+eZpnlDf//ARUNGj9r6Lmg63Ym7TmPmhbUs+ttGnLUO7l0f5at/6qMzkrXAKA6cDVHRM9kQ2Sa6CJEsDPbI84QNn4KBUzGYUauSTMSJDifQ8/pRu7kUTs/JM2Zz7fXX81Kinv9+Mk4qb+eDSgAvdC2e0PkvR/pqmSYEHHDGJNix8UUO7NtDLj/R3dqCeCpHMmcQcGuWXL8C8teThB9staAayEHbqiALLmkg2O7C6VNw+lUcHgXFIQi0OFn1LzZcDuqllP+qquqHVFWtP1LkUo6URrviiivmpFKpr/b19V3Un+lQwm/LET4VFBeoTgVXUGXmRbUsuLwBLeTgvg3DfPXP/bYs2qCUyU4hCtlRy6yQQznymKh4zKmYzKgVJJJperq7yOWyxUE7uiRKVpx6Op/+zKf5+QEv33o+TSZvFqNVYeJwfEs0kNKhwQuJRJKunn7S6fT44C+OvElf50G8DoFHyUEufcLlrzcJP9wq+eZLMJCB9lV2pGp34/QpVrRyK6hOBUW1Ekieegcrr2hjzjvrUBzUSMkVqqr+naqqtWPBpY0F1cc//vFZuVzua4MDQ28fyvUoTRfr1J+qIhUDYYKiWStArgDMvKgWIWDT93u5d0MC0zS5/i01tAXUsgXnsZYhSsuYiwsYZfVXEqeQ1HsktS6DngO7yGazxUE7Ws5ICAGqxgXvuRxdz/M/N91ILh/j0ysVfJpZsuY50RErf05ah3jO+syJRJxMOkPA7x/30o5hGOzd9hJzmv24FRP0zHFDJSqSn/dsk3xzvQ3VqUEWvLeRQLsLp9eGyjMCFQoIBEjwNlhwKQ6FnT8dqDHz8l9UVXVIKe8wTXPUJYS1avJ3xRVXzM3lcjcM9A+8LWr2Kq3vkdSuVEG1ejNYAyVR7OVFl4AZF9YCsPmePu7blEJIyfXrArQFFXvFvGLTRcmSjizdJDFGKY0KBJ0mk/wmhzq6yGSyVbu4VIOqsF1dczi56H1/ixCC//mf/6M33sO/rQLDBGOiXBW6zdhw5QwYSsPmPnB4fCgC8np+3LNCIQSZVIKN2/ZwwdRaXEreivonyFP1JOGerZKvvwiDeWhfE2T+exsJTnLh8I0BVbELo/WPJ+zglI+1gCnZ+eBgrZk1P24v2N9lmuZgKVxKJVSf/OQn52ez2f/q7+u/cCDfpTa8PU/daiyopE2wsP4VqhW5CrI4w/ZcjlonP9qS5iuPDdMRzdntfiw5lFIv+70wQyvIHmaFHNq/K1In5DSZHISD3YMkYhF03Rj3oBX+dThdXPS+v+M/vvIVXtKn8Ynfw1MdVrSZiFmRpoE0chimZDgHeyPw6CF4tgumzpyNPxS2useM61IuoCgquza/RLTnEKdM8iGSA8cNVqlR/8EWyTfWw2DOlr9LGqmxoXIeCaqSjJU0JZ46Bys+2cacd4URTkKmYX5CSv4eq3FbURa1Cvmbncvl/nNwYPCiIb1HNP+NQfhUBSmM0csUAoQUoMgRWQyWymIf927OWLJ4lpu2gCiTtkpJLJXKoiAWl4lAkRKvKmkPwOMHehns6UCfPYfxNu4vRC5FUdAcDk475wJuamjgtm9/i5uefJygksOQ4HS6jtq9RkowjTy5VJyOYcnOPnjkIPxyN4SaJ7NizemE6grrjco4PhsYeo7HHn2U1oBgfthE9g9MXJ6rZNQLnurbL1kFe+1rgyx4XyOBthGotCNBVXmCmuCu1Vjx8VaEAtt+3F9j5sxP2m/7PbuiFLVg4D/2sY/NMQzj5qHBoQuisldteadJeLUYiVTV3syOXIUPI4RA0QTByS6cPpX+XRk2Hc4zmDZZ3iQIOitqgkrLYKlW1D9Sb6QIk6wu6UlKnjyQZe6SFUybOddulKaOuxlIsdhOUahvbmPVqafR2j6JfV0D6Pk8b7/4nbS1t+HxeMZcK3z8j7/j4I4NNLry/G53hjs3wTM9GpNnzGbdBW9n7qJlTJk8mbq6WlwuZ9XXKa+WUDmwZztf/++b+Yc19SwPDCLjvdbJJo5d/gpQfd2e/bWvsSJVsN2F0z8xqCqjl8Or0rDARy5pMLAz5ZEmy+y1xE2AoQF89KMfnZ/JZL4Wi8beFpN9StPFBnWrQCpHgKoycqkSVQhrtb8GZlxQCxK23tfP/VutorXrTteYFMDyW4VTX8qKVjuSkUZZJb5MWn0bJgWs7Hl3f7Q4Myz2OZ1AGyNrsKGuoYl3vO/9rD7tTPbt3ML0GdNxu91HmbwZbOjS+VzcgeZppH1mOytmz2Ha3EVMnjqdyZPbaWiox+12HzX6CSEw9Bw/vf8+GpwZ3jLNgYz1TChhWzWlkLCg+sZ621OtHoHK4VNx+pSJQ1VyMggErqBG7XQPiiYw89IPNNqZ+bz27ne/u7Wvr++6VCp1YcYZE+3vVqhbLarL35jhVyIUQT5lsP+RCPXzvQSancy4qBaEYMsP+7h/Ww6k5LrTFSb5bTNfuTOnzNyPju9OBeo9UOuGjt2bSScTGEb9MZWqFIr+VNXqv9AyeSpNbZMxTRNNGzsCmlJy+rpzaWttpaGpCX99OzldR3W4qa0NEQ6HqakpXNzg6Nf3UVWVF554nId/+xuue/t06mUvZBPjWI0be/bXa+epvvUSDGbt2d8lpfJ3nFAJgalLdv9ykPW3daGnTQP4E/C7QlWylk6nJw0NDq0ejg+LhrMFoeUBK1KZ44RKjkD10h3dbPpBD60rAqy9ajL+RiczLwghBGz+QR/3bcshpcmXTrO8EmXbt46wVl4Ivwp4HTAlCH09XaRSqXHNDI8MlyhWRpiqWdaUbayQsO6CiznzvLeTTKVIJhLkcjk0TcPj8dj95x2oqnLEaFWAqq+7g2984xucv7CB82Y6obPL/gzHnlIoRKqhLExaG2T++2z5szPqDo+C4hQoyrFDtevBQV74Tgep/rwB/NkuBOy0S5QNNRQKyeHh4fZEIrF48NCwKtwmtbPcVnLsKPJSBtXtXWy8uwczJ4kdzDLcmaVpiR9vWLM8l1dlYG+GTYcMBtOSpY2SGleVE/MoBWp5A/ZH4S99bs4462zqGxrLrlAxUbjGe8ndyu9tmiZCCJxOFz6fD7/fajHpcGijoBqrCjUeHeKmr/w/Ut17+OI751AT3YpM9E/IW5VC1Z2wItXX18NQHiatCTL/EiulkOjJ0bclibfBwYHHorhDDjx1DssjTwSqvMnuXw3x/Lc6SPblzBKoDlCyuULt6urKOZ3OnaZpNiUjmTk9m4dVh09QN8uDoiljwlWEKmnw0nctqFxBjeUfbcXUTTqfjTPckaVpSQBvvQWX5lEZ2JNm02GTvhQsaYSQe2RmxDgvs9MRh0cPGCxbPI9JM+YUjXZltl0oSvFqDxMF7GgFe6W7mwv1YIUeXWO9VhEqVWU4MsjNX/4iOzc8x03/cDrTzJdhYI+VXhETj1Q9iRH5G8rCpFMtqGpsqF68tYt9Dw8xsCPFjp/3EzuYpXmpH3dIQ5pyXJc3NvOSPb8e4tmvd5DqzxnAo3Z16QHKN1fkVEBLJpNpKeU2KWVDJp6f07c1oTgDKuHZHhR1NFxlkaoAVUDjtKsns/DyJhrmexncnabzuVK4HAQnO3F6Vfp3ZtjSYdKfgmVNFXAdZVpumtZK/JMHDabMnMfsRcvK/ExR4hSF2EAvB3dtpibcgKo5jlrhOd7Ga0eLcGMBVZDdwZ5Obvryl9i6/llu+NBpLHJ3Ibs2QT41Lm9V1VPZGXVL/mqY/74RqNbf0kX/1iTh2V5mvq2O2MEsvRsTDHeMwFVWRDiW/P1ikOe+1UGqP6cDj5VAVShZLmwF0wvbv0Q+n09KKbcKQSifNOb1bU0qmkehfq63DK5SqNbf1sWmu3tw1Wic9rnJzLzQ6pPga3TSMN/L0F4brsNZGhf5bLhcuIMag3uybDxs0JeGZY3jh8uUkDXhkZclWsN0lq9Ygd/vL7sESmHAf//rB/n0pz5DPNLPjOlT8QVrq6YfjsWfjbcDYNGzKdY6xdYXn+G//t8XiRzawQ0fXMNSTxey40VkZnjcElgtUn1jDPlbf2sXfVuTNC31c8Y1U5hxfh2h6W76tiTp2ZBg+LBlWVw1WvVJmR2pdj04yPPf6SDZV4xUtwEvM3pzhQ6YaqllNk0zoSjKDiFEbT5pzOnfllQdXpX6Od4yWcwlLU+16fs9uGs1TrtqMjMvqCvpo27BlY0bdD43TPRghkCzk+ZlflSHIDjJhTOgEdmfZdNBg74ULJ1A5DIkPH4IYvhYtWYNobr64pXrC4ObScb59v/cSJ2SZM/2Tfz+kcfwuxRa2yfjdHtOCGDjhVBRFOKRAR6874fc9LX/YnZNnq+8Zy4zOYDs2ozMxCfkq0o91d1brOTnKKi6crx4Syf9W1NMPrOGs66fSv08H0iomeSmdqaH3s0JejYkiB3K0rTEh7sELmuXlMDISHb9cpDnv3W40qgfHAsqQKoV1aKYppkAtgtFNOSTxqz+bUnVGdAsWdQUELD3oSGe/0YnRlay/KOtLLi0qfySHgIOPBZl/S2dZCI6M86vY+k/NOOu0RCKnURtd+LyafTvSrOtw6R3nLIo7MXeLf2wd8hk9Rln0djcUn6JOUVhy4vP8MB9P+LLl6/gA0tcdO7fxV0/e4StW7fSVB+ivrEZh9NVVh1xogAb8XcK+Wya5x7/Izf911d55s8P8dF10/nkGQ2Eo5sx+3Yj9PS4oBrLU33bTilMXltTTCm4/Cq9mxLsfTiCNCXz3t3A9HPqyiJosN1F7XQ3vVuSxA5maFkeIDTVXS5/OcnOnw/w/Lc7SA8WoaqUv6qbK9QqpchSSpkUQmxRFKVWT5lz+rYmVYevIIsCh1chdiBD7GAGPW3SMN+Lr9FZXEc88FiUp/7zIMOHs8w4r5bTrp5MsM0FQljPSZl46jQC7U5cQY2+XZbn6k3B8nHAldGtXSR/OiRYc+ZbaG1rx+32FLu5mHqe791+C65EJx9eGaQ+sZMz2nQW1gvWb9vLvb98hO2bN+LSFML19bi9/hOyObXYUUYIYoO9PPXnP/Dt/72ZB350D0vqDb508SzOakri6N+KHO6yjPoxeqrvb7U9Va7gqRoIttn1VD6V8CwvqlPQuyXJwI4U7pBGeI4XoYwEgOBkN/mUgVBg0eVNaB6laHXMvGTnLwZ44ZYO0gP5Qp5qPFDJSrBGwaWq6jahiFA+Zc7t35ZQNbcFl7fBQfNSP8OHs3Q8M8zA9hT18334mpwceDTCU/91iOGOLDPfVsdpV08h0OZCAn1bkzz+pZfpfG6Y5iV+y3O1u3DXaAztzbL50Ejkqj0CXNKOWr/eC7NnTmPK1Kk4NYE08khD5/DLe7nztm/zkbOnscDVgzmwD9XIMi0kOW+mm5k1Blt27OWBX/2eR594ht5De3C53TgUcHl8ZW86lgnHjoyKsGA2chki/T3s2LqJn93zPb57yy08+tufMzuY5dPnzeADi53UJ3bC4F5kJmZl1sXEPVV3Ar63xZ795e3ZXyFP5VeLyzQOv0rTUj+qJuh4ZpjOF+N4Qg7q51pwIaDzuWE2fLeboT1pGub5qJ3useQvJ9n9q0Ge/2YnqYEy+SvM/qrKX5XU46gskmqn5t2qqk4RQlxtGuY73XWqc8Un25j37no0j8Lw4SxPfvUgBx6N0rTYx4y31bH1/j6GD1lQrb16Mv5mq29435YkT3zlAH2brb1Fk06vYe2Vkwi0uMgO6xx4JMamu/vIDGR5z2yT/zhdMq3G/kAVn9IwoTcFn3tcYa/ZyqSp0/G43SiqiiIUhiJD+PNDfP3986jtexaGeywoBNaisMNJBg9bB1V+szPDU4dydKZczF+0mJtvuZPauvCY6QKATDpNLDLIQMd+eru72H+4h7379nF49xYGBgaZ1eDijDn1vGV2kCn+PFqqDxnrRGbjI9cROoaUQncCvrdZcssGS/4mnVbDgvc1EGh1kU8beMMOfI1OFIdAUQVCFehZk43f6+al27vRPAqn/vsk5r6znq71cZ74jwNE9meY8zdhTv23SXgbnRhZyc6f2fI3lNdto35UT1X52dUjfKdSWdyqKEo4nzLn9G5NqM6AFWo9dQ6al/iJd2bpeC5O53Pxoqc67erJ+FucCGFFqie+fIC+LUnq53vxNTjoXp9g+HCG5qV+vGEngTZLFvt3ptly2KQnObbnEkDACUtaHKhSx6tHCckINfoAAX2AuaE8/3RGM61GB8Q6rByFsC4FZ5Um6Ghmnja/5MypDs6frhAQKX62PcffvOvd+P3+MS8JLITgrm/9N1defS1/eui3bHn+KYZe3kxtvpcL59fwsbMncdmyIKc2pKhL70cM7oNEH+SzI17qGKG6e4vkOxuslMLk022o2q3Z3wvf6iR2MEPriiAOn2rXcwpUh6BhoQ9FFXQ+F6d7fZxMzGDzD3uJ7ssw52/qWfvZyfganRg5kx0/GeDFW7sKUD0CfPcoUFW9aUeoZjWwNihiGMZBTdNuFIow0oP59z3/zU6HnjFZeHkTwUkuTr9mCgg4+HjMilRXTSbQ6kRK6N1sR6otSVpO8XPmdVNBwBP/cYDDTw/z9A2HOO0qC8Jp59YggI3f7+Wnu62Oz18+w4pcyBG4CgM0s0bn31c6waWBpoGwe13JHGS2IWMxpJ4fGcfSdgvSQOZSQBo/gkaPiYLJwMAADQ31+Hy+MX3U4EA/M0PwufefQ6szQaOWwG8OQ3YYsp3Ivhgyl7Iu5HQkfRin/HUl4K7Nku+8BFHdilTz3mPVqMe7crx4ayf921J4wg7ruUpJztGUODwqSz/UglAE62/tYsMd3SBgzsX1rP3sJLz1DvS0yY6fDvDCrZ0FqH4P3AEcOoL8jbUId9Rr6RQjl2maCSHEdillnZ4xZ/dtTaqqU6F+ng9v2EHTIj/+FidL/q4Jf6s12+rbnOCJrxykb0sST1jjzOum0rzMjzfsoGGhj8i+NJ3PxokdztC0yPJcgUlOXAGNoX1Zthw26U7A0sYKzyUYqYDQc5BLQDoK6QikItbPuZS1zexIgm+/xGBasqEXHu92sWrtaTQ3NeHxeMcsm3nqT39AxLv56JltNMQ24RjcCdHDyOEeSMeKlzARcMwbTUuhumOTJX8xQzDZlr+adhfDXVlevKWLwZ0ppp4VslXCVXVNVNUUGhdZkWtgR5KZF4SLUOUTtvx9p5NMJJ+3I9XtWD1GE+OVv4mAVZaKkFImga1AjZGVcwa2pzSHV7FkMeygabEPV0ADYXuqLx+kb2sSRRPoGROhCJqW+NE8Kr56B7UzPHT8JUb/9hS5uM6ktTVoHoVguxN3QKN/Z4ZtHYYli9XgKoVszC0hR/9yA2nYOgB/6XWx6tTTmDSpnWAwMCZYTzzye2Idu7lgpoZjYAdkhq1KWDiuXcvV5O/OTZJbN0A0D1POCLHgvY0E29zEu62M+sD2FE6fyqp/aadlRaBYQ1lmHUrgaljgJTzHy9yL6/E1OtHTku339/HCbZ1koroO/MGWv8NHiVRHvGnj+K5lsggcEkLcJITI52Lm+9ff2u00DcnCy6zpKkDsQIYnv3KAvq1JWlYEmPOOMJu+38POB/uRpuTUz07C4VXpeGaYdETHE9ZoWxPE6VctLyRg6rk1AGz8Xi8/22X5k/84XTIjNPrAHe+2c1PaF4WXjKtaQiIxjTwylxzZ3XOcn6EaVHdssuRv2ICpZ4WY954G/M1O4l1ZK/m5I4W7ViMb09lwVzeBNhf187zF16kGl8OjMv3cWivYZ0y2/3iA9Xd2FaB6GKsJSEH+hkuXaTiBl5WrKotASgixXVEVn5425/VtTWqqS1A/14fqtKJT90sJvA0OzrhmClPXhQhN89C3OUHnc8Ok+vMM7Eix8a4eHD6FU/9tEnPf1YDiUDByJvmUidOnEpjkxB20M/QHDHpTVWSR4x/QoQzsGoRn+92cftbZTJs2lWAwOHbE+tPviXfu4aL5flyZfquz9HF+llKoOuPw3U2SWzbCsCmYcmaIee9uwN/qQs+avPDtTvq2JJm6LsTaz04iGzfoeGaYwV0pa3LU6BzpSlMFLhAYWctTvXhrJ2lL/n5vR6pST5WaiPwdK1ijZovADqGIkJGRs/u3pzTNrRCe48FT56B1ZZCpZ1lAYUJwkou6GdYyQsezcbo3JHAFVdbY01+hWl928w972fbjPhrm+/DWO60MvV9jYHearYdNOhNHz3NN9AtFjgWsrr1ctCB43GDJKlDdYctfTC+JVC1OnD4VV0AjNZDHGVA5/fNTaF4aoHGRn9jhLJ3PWnA1zvfhbXSWv0FJDs7I2Ub9O0Wo/mBHqsMnAqpjAavSc6WEEFsVVakxMnJe//aUqroUwnO9uIIarqBWbJ4msNYIa224EFiRqgyqHl68tYuhPWlihzJWPVe9lYpw1zjo32kt/3SfwMj1WoJVVf7sPFW8Qv4K5cSugEbTIj/uGo3mZX5r50xIo3GRj+HDGTqfizOwK0XjAj/eBkdxIoBd5WvkTLbfP8D628oiVUH+4mNANeGbehzjUYhcBbi8RkYu6N+WVIUGDfN9KJooqYqwDmJwkovwHC9tq4LMvCBsGfu0BdX6W7sQAnyNDga2p4gdLIfLU+tgcF+GzQdPnCwWwRqCZ/teXbCqyt8GiJuCKWeURyqnX0Wzdyg7fCp1s7wjeTYJnlqNpiUBhjuydD4bZ2Bnkvo5PrwNjuLfGVmT7T8Z4MXby1IKBaMePxGR6njBqgbXDkVRAnpGzu3fntJUB9TP9aI6lFFwBdosWRSq5cc2/aCHl27rIp8ymXWRNQ2OHc5YqYiDGRoX+/E12LJoe67NB00647C4AcKeY4dLAtEM7B6CZyYE1j4uWlBzTGBVRqqOOHx3o+S2TTBsCKaeZeWpAq0uhjuyHH4mRt1MD64azdpqJ8So7ypNiadWKy61db+YINDipGV5ACEEekpa8ndLMaVQgKrjREN1vGBVymJaCLFdVdWgnjHn9m+zPddcL6qzvFiwMGMxciabf9BTKMi3So+TBq0rg8y6KFys5xqRRYe1cB2wMvTbOk0OD1ue61jhksBwDvZF4OleN2euO4cZM6ZTU1ODqmll14suVIw+9affE+vaa4GV7psQWNU81Z2bJLduhGEdpp5tGfVAi5WnWn9LF/sfiVAz2U3zkgAgqn5HIQTSlLhDGo0LfQTbXcx6exhnQMPISLb+qI/1t3eWzv7uOkqkOq7biWjANFoWFeHV0+b8vq1JTdEEDfN9xchVOAh61oLqxVu7AFj6D834mpx0r0/QsyFO87IAsy8KM7RvBK7WlUE8IY1AmxNvncMy9IdMOuIWXHXHAJe01x67EvCnwxrTpk3GqUiGI4P0dXXQ03m47N7X3cmTjz2GKzfEBXO8aKkea8fyRGvUjfLkZ9wUTD3Tkr9Ai4vhTiulMLArxeQzQiy8vAl3SDvidyvCVeugabEfp1/FSJts/XE/L91RhOohO6N+NKjk8UBxIgqQKheuXZqmtQOfNg3zcmdQcS/9SDOL/rYZh0cBCXrWZNP3e3jp9i6khBX/3MqSDzWTjRo8dcNB9j40hL/ZyZnXTSXY7uTJ/zyE5hSced1UvA0O9KxJPmFw8LFhNn6vh3hnlr+ZKfnqmZI5ddUXro+U4c6ZcHhY8NXnVLZEXDidTuuSdKNaVguEUPE4VT59/gze1tiHGNhdXIscd0bdEHQk4PaNku9uslMKZ9QUI1WsI2MlP3emaFsdZN1XplHT7hr3xuhCkZ6ekmx/oJ8Xbu0gG9ML8ncb1m6axImWv4kkSMd70pclUXVd71QU5f+EItTssHHpxjt7XIoqWHBZI06fipEziexLk0+ZeBsdNJ8SQHMpqI0Kp101GaRVTPjkVw5wxrVTOPtLU1GdCv5mJ6Yh0dzWZtMp66zyhw139PCbfVkk8J82XMjxwSXs/YrTQvC1c9x0mGFwhxAO16gXsHZ9a9R4VCa7E4jBLqs95kTlrwSqWB6mrQsx9931BJoLkcpapgHQMwb5lDH2CsMYpdBGRrL1vj7Wf7eT7LCeL0l+dr3SUJ0oKRxLFtNCiG2KoviMjJzftzWpqU6F+rk+XAGVxgV+Ej1Z+rYkGdyVIjzHi7/ZidOv0rzUT6ovR8/GBKpTYdYFYdy1WnGBNbI3TT5t4g078Lc58dQ5GNiVZtthk8Nxa/mnfgKyaJdX4XdK2nwGre4src4Erdpw2b1FG6ZFi1GX60YZ7kDmU0et/pQV8teZsGZ/t220UgrT1tUy9131+JudFlTf6WJwV4r2tUH8zU56XkowtMeud2t0HHHoC0V6RtZk6/39vHRnJ9mYrmNtJH1FPdUrDdYoz6UoyjZFUbx6xlzQvy2pCRUaFvjwhDWalwZIdGfpeCZO/7ZkES5XQC2a9XnvbcRb7yi+eM+GOI998QCdzw3TtNiPr96Cy1vnYGhvhi0HDQ7Hra1lEzH0QmJJWj5r7UTOxMe4D9sL3Ma4SooLUGUKUG20jHpSWp5q7rutPJXTp9KzMcH+P0asGvXrpjLtLSGiB63Z8eCeFA2lcFVk1QuRSs+Y7HhggBdv6yITLUaqO05k8vO1AmsUXFg19AEjI+f270hpiiYIz7EWrpuXWHB1Phenf3uS+rlefE3WgW5a6sdT6yiOUPdLcZ74ykEGd6aId+aIHkjTuMiHr8FOotY5iOzJsP2wwYGYBVe9d5xwiWO8TyBS3bZRcvtGSJgjKYUCVA6/St1MD3WzPCywt265QxpNi/3EDo3A1TjfV0x8jpK/rFVP9cItnWRi+VwJVJ2vJlSvJFjVUhHbFFXxGxk5v39HSlOdgvBsq1iwaUmARE8hsZeiZXkAT7hkl66AnpcSRaimnFmDt95J1wtxogcyNC22opu/pSCLGXZ0GnTYkav+OPJcJ2SZxo5Ut2+0FpSnnV3LvHc34GtyljXocPpU6udZu2UKa3rukEbTEj/DNlxDe63INZJVL5G/+/pZf3sXmWg+b8/+7rKhelXk79UCq7rnUhW3kZEL+7alNEUVhOd68YYdNC8NkOzLobkVpp1Ta5XfFKGK88SXDzK4K8Wsi8Kcce0UJp1WY9VzPRcneiBtyWKDA3+rE2+9g6G9WbYeNOhMwOJXGa5S+euyjfqtGyAhBdPOtuXPjsrFBh0OBUUTxV1OpQlld0ijaamf4YMZOp6NE9mfpn1NDc6AtUlXT5tsv7+fl77bRTqSL3iqO+3k56saqV4tsErhMm24diiK4jcycm7/tqRDaIL6uVbkal0RYOpZIfzNruLX7l5vy9+uFLPfbmXlfU1OvGEHjYv8RF+21seiL6dpXGidyYE2F55aB9GXLbgOTlQWj/cLl3iq2zZIbt8ECWz5K4HKUehPZUNVmVEXJTNBT0ijcbGfeFeWQIuLyWeE0DwK+YRkx4/7rXqqmJ47GaB6tcCqLouKEtSzcu7A9qSmOC3P5arRcPjUYi8By1MdYHBX2lrqudKCSpoSaTdcDba6OPRUjKHdabJxg0mnWcWCgTYn7loribqzw+DAsLUp9pWKXLJK8rOYpyrI33saiv7RgkqUQDV2c7vCG7hrNNpWB5lyVgh3SENPS7be28v673aRHdZzFfL3mkH1aoJVTRa3Kori0TPmgj57ttg434fiEFZKYX+aR697mcGd6eL6YQGqQtohPZBn0w976NmQwFvvYNHlTdbityIQCpYshi3Pte2QwSF7+edEwyUr5K/bhuo226hPX1fLvHfVj/JU5ZFqfJsLHV4VzaWQT5tsvbePDXd1FZKfv8Nq1djxWniq1xKsqgvXQhFuPW2nIoSkYb4Pzalg5CX925I0zPNy6mcn4Wt2jhRrKoLUQJ7n/reDnT/vx1vvYO1Vk5l1URhFVey8lEBRwd/mwlvvILI/w9YDBoeHT7wslkLVEbdmf7dtslpzTzrV6qPuK3qqI8vfkddILLrycQuql+4sg+qOkyFSvVZgVcpiCqtY0Kdnzbn921MOxSGon2N5rvbVQSadFsJb77ChsmZA6UELqh0P9uNrsKG6MFw0vgVZsXYmW9UUnrCDoWNNRYxT/jricOsGyXc3W1ABxYmJv9VpRZsy+RMTaLBmLdPk4yab7+nlpbu6yMWNXEny86SB6rUCayzP5TOycr6VRLUMvTOgoblLFq8VQXooz7P/18HOB/vxNjhY+9lJI1DJEahK4RI2XJpTpWdjkt39koO252o4jqqIUqgOx+GWDZI7NkMiRx7YqghFTfbnfelInubF1i4mVTsGqIq9yEw2fb+Xjd/vIpcwcsCvgbuPAtVrcnutwBrluewMvbuQoTelpHGBD9Wp2Ot+gmR/jmf/t5NdNlSnlUSqyh5exX70Qth+TLcaj+1OIaVgbwQODdupiGOIXKXydzgOt7xkQZXMk7UXe+8WijgoEDOHO7KB1ECepkV+PPVOG/gJRCobqi339LLh7mKk+rXtqU6qSHUygDUKLlsWPUZWzhvYnnJIaVWiai4FocDuXw+y4Y5uvPVHhqow8gWoUn151t/Wxe6HBjHzMiaEeAEhnPuiBF6OwaIGaBwnXJVG/dAwfGu95O6tkMiTAX4F/BDolFLuVhSlSwgxJ3YwWxPvztK4wIe7Thv34REIcnEbqju7yCWMjA3VXUB3hVHPnQxQnQxgjZWhd5l5OX9gR8qBAvXzvGguBXedhpEzmf+exmI/LsZoF15oGpbu13nhm53s/u0AZl7GgfuklD9WFKULxOz9Ufz7IlYlapPvyHBVZtQPD8N3XipClQd+YUNVGPBh+2LtPcDi2KFscLgjQ8N8y0OO1UWvTP5SJpvL5e+XwPeBnpMVqpMFrMrIlRFCbFcURTNzcnH/9qQmpbRW9+sdtK0MEp7jRVHGiFQlPivVm+e5r3ey+zf9GHkZswf9V8CAHU0Og5i7L0pNMXKNAZesIn/f2SC5czMkdbLAz4F7sMpSChfmTgFpKeV+VVV7kSyOHcjWDHdmi0nhQkJViOqeavMPetn4/e6C/P0S+EHJe1SD6qS4nSxgVctz7bDhWtC/LeWUpqRxoQ+HVx1b/krO/mRvnhe+3cmuX/Vj6jIK3GsP/oA96IVo0gHM2xelbn8UFtVXj1zV5O97WyClk7EH/IdVpCmDddGivJTygKIovcCC6P5MbRGusKNsD2Ah0ubiJlvv6WXDXV3kEka2xFN1n8yR6mQEq1rk2qGqqsfMyXkDO1NOKSUN87yoLqWqBEpheZJUb57nv9nJbguqmH2W/xwYsqEqGl3TNF9WVbUbWHwgRu2eiBW5KuGqhOr7WyGZJwc8aL9+NWnKlwy4YcPVLYRYEDuYqYsdzFA/31ds5lEpfxu+10UuaRR8291V3iOLVWB5UkF1MoJVCVcW2KYoitPMyUUDO2xDP89XTEMUfJYUEkWxPNXzI/I3bPuRX5ZAlaiYPRmmaR5SVbVbWnCFXo6VRy6AjO2pbtlgRSobqp/bkWosqGTlXUp50IpcYvFwRzYUO5SxqhXCDhACPWWy6e5eNv2wu+CpfnGE9zBOJvk72cGqBtd2RVUUMycXDWxPOUxpZ+iLcNmeqkfnhW91svPX/Zh5GbUH5BdYV6Qqhap0UEysBfJDiqJ0AvP3RgkfiEkW1Ft5LqsmHr79Ety5uSh/D9qeqnuMJZTKa7eULsYfUlW1C8mi2IF0bawjS/1ca/a7+Qd9bLq7m2xcz5Z4qteF/L0ewKomizvtyDWvf3vKKaXV+1RzWx3Fkz15nv9WJzt/VYSqUv4qoaqMJgW4upHM3x8jvCcC88OQN+Gb6+HurZAcgeqHE4CqGlwHFUXpklIuiB3M1EUPZBjcnWbLfb2FlMJYUJ208vd6AWtU5LL3LbrMnFzQvyPpAGvhOhszeP4bnez6TT+mNfsryF/kKFCNGnDTNA8pitIjYfHBmKzdE4GNvfDjncWUwoNHkKYjQVX1vYQQPcDi4Y5sbf+2JEZWZqukLarJnzyZB+5kB6u6LCqKomfNxQM7Uo5MzODlP0fZ87uBQqS6xx6YoXFCVVWqFCE6JSw6EKN2cz/kTDLAT0ugSkwgUo35Xlg9E7qAWfY1q0rzVInXk/y93sAaJYvADiGEomfMhX3bks7B3SmkQcQe9IL8xScAVVW4hBAdwAw72/BzW5p6GbluzLFAVfleBlaPzxexGsn+Aei3X7twbZrs6yVSlaZnXi+fs7Ap1gG4hBBNwCellJfbA/t9O9cTqxj48UJVeB+l8B6AD5gP1NqDP2znplIlA34sUJW+l4a10ddp/6zZAOXs18+93qB6PYFVDS43EAbm2L8fLjnDk/a/E4GqGlyOkkFXqgz4sUJVeuwV+ztp9r/Cfh+jRPpOyLb3N8EaP1zOEgAUeyAqz/TjiSZHGnDjOKCq9p0UyruqmhWz1tfdQPE6hUspkY6CVzTtQT8RA1854KXeyDzBAy6O4sVed7f/D43L1HAOaiyKAAAAAElFTkSuQmCC" />
  </g>
  <g transform="translate(16,-16)" id="directions">
   <text x="-5" y="16"  class="fil0 fnt4">se</text>
   <text x="-5" y="11.5"  class="fil0 fnt4">1</text>
   <text x="-5" y="-9.5"  class="fil0 fnt4">3</text>
   <text x="-5" y="-14"  class="fil0 fnt4">nw</text>
   <text x="10" y="-2.5"  class="fil0 fnt4">ne</text>
   <text x="13" y="2"  class="fil0 fnt4">0</text>
   <text x="-16" y="2"  class="fil0 fnt4">2</text>
   <text x="-16" y="-2.5"  class="fil0 fnt4">sw</text>
   <line class="fLin sCi5" x1="-10" y1="0" x2="10" y2= "0" />
   <ellipse class="fil2" cx="-10" rx="2.5" ry="1.5"/>
   <ellipse class="fil2" cx="10" rx="2.5" ry="1.5"/>
   <line class="fLin sCi5" x1="0" y1="10" x2="0" y2= "-10" />
   <ellipse class="fil2" cy="10" rx="1.5" ry="2.5"/>
   <ellipse class="fil2" cy="-10" rx="1.5" ry="2.5"/>
   <g transform="rotate(315)">
    <text x="15" y="2"  class="fil0 fnt3">North &gt;</text>
   </g>
  </g>
 </g>
</svg>!;
}
