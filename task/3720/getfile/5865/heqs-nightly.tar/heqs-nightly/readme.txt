Heavy Equipment Set (HEQS)
--------------------------

http://www.tt-foundry.com/

Please see the fine user manual for more information about the set :)

Name of this GRF:   {{GRF_TITLE}}
GRF_ID:             {{GRF_ID}}
MD5 sum:            {{GRF_MD5}}

Repository version: {{GRF_REVISION}}



--------------------------

Changelog

*version 0.6*
Added Grindelwald Foundry Transporter (available 1972).
Added Kander Foundry Transporter (available 1967).
Cargo table support for FIRS cargos ALUM and SCRP. 
Many internal changes to layout of sprite files.

*version 0.5e*
Added Wolfpen Ridge Dump Truck - (available 2005)
Added flashing amber beacons to more vehicles.
Fourtrac now has more livery variations (uses 1st company colour for mail and goods). 
Set correct hp, weight and co-efficient of TE for all vehicles.  For use with Terkhen's patch for realistic vehicle acceleration, or if realistic acceleration hits trunk.

*version 0.5d*
Fixed Camelback Mountain Mining Truck - now correctly builds two trailers instead of one.

*version 0.5c*
Added support for FIRS sand cargo (also any set with "SAND" as cargo label)
Restructured sprite layouts and some code for mining and dump trucks (doesn't add any new features)
Added Cascade C10 and C16 Logging Trucks (available 1972)

*version 0.5b*
Added Red Peak Articulated Crawler (available 1998)

*version 0.5a*
Added new graphics for No. 9 Bulldozer for 1970-1980
Added new graphics (smaller) for lower capacity bulldozer trailers
Improved sprites offsets for bulldozers /trailers
Removed redundant vehicle IDs
Removed drawbars from some articulated vehicles to improve appearance
Drawbar graphics are now invisible to improve appearance
Cleanup of psd / pcx files: organisation and filenames
!! Vehicle IDs changed.  Will break saved games using v0.4

*Version 0.4e*
Added new graphics for No.6 Bulldozers from 1993 onwards.  
Code cleanup for all bulldozers (sprite sources)

*Version 0.4d*
Moved to automated build system (thanks to planetmaker)

*Version 0.4c*
Articulated vehicles now provide correct capacity information to the buy menu (thanks to DJ Nekkid).
Removed unnecessary hard coded strings from the vehicle window about vehicle capacity.
