ECS & FIRS original vehicle set (EFrefit.grf)

Enables standard TTD vehicles (trains, cars, airplanes, ships) to be refitted to ECS or FIRS cargo.
Uses mostly default TTD graphics, those new are from (C) Michael Blunck's Cargoset 2003 with his most kind allowance

Parametres
1st: One secret parameter for secret choo-choo trains
2nd: Enables universal wagons and road vehicles which can be refited to all cargos but passengers and mail. 
Use in case you miss some cargo from cargoset, otherwise it is recommended to disable this.



Please, report aby bug or malfunction to http://www.tt-forums.net/viewtopic.php?f=67&t=52116

Version: # 2012.08.04

Coded by Jan Skoch

Special thanks to all who contribute to NewGRF wiki http://wiki.ttdpatch.net/tiki-index.php?page=GRFActionsDetailed,
 and to Josef Drexler for hiw astonishing work with TTD


