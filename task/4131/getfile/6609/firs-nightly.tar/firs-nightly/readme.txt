====================================
FIRS Industry Replacement Set nightly-r1371M ReadMe
====================================

----------
0 Contents
----------

1 Preface
2 Downloading FIRS
3 Using FIRS
4 Errors and warnings
5 Compiling FIRS
6 The FIRS NewGRF
7 FIRS Web Links
8 FIRS License



---------
1 Preface
---------

*FIRS 0.4 Release Notes*

FIRS 0.4 is a fully playable release of FIRS featuring 44 industries and 27 cargos.
http://tt-foundry.com/sets/FIRS/schema/industries?economy=point_4_release  

In early years, not all cargo chains are complete, but there are enough other
chains available to keep yourself occupied while waiting for the industries to 
become available and complete the chains.

Nightly builds of FIRS are available, but aren't recommended for most
players as they often contain work-in-progress!  Thanks though to all those who
do try the nightlies and report problems :)


*Getting Started with FIRS*
FIRS lets you get started playing straight away with easy-to-understand
gameplay:
- there are plenty of familiar industries and cargos you'll recognise from the
default game
- FIRS adds lots of exciting new cargos and industries to play with
- primary industries like mines and farms _always_ produce cargo
- secondary industries like the steel mill and cement plant _always_ produce
some output cargo when an input cargo is delivered.

For players who want more, FIRS also rewards you by:
- increasing primary industry production when you deliver supplies regularly
- increasing production at some secondary industries when you deliver more than
one input cargo regularly
- introducing new industries and cargos as time goes by.

The pixels are lickable and work brilliantly with original graphics and OpenGFX.


*More Info / Things to Watch Out For!* 
- primary industry will not increase production unless supplies are delivered. 
- some industries are available from year 0. Some industries (and the cargos
they use) are only available after a certain date.  
Intro dates can be found at:
http://tt-foundry.com/sets/FIRS/schema/industries
- FIRS works well if the colour of the mini-map is changed - this is possible in
recent nightly builds of OTTD (in advanced options -> interface) 
- FIRS 0.4 is *not* savegame compatible with FIRS 0.3.  
The grfID was changed in FIRS 0.4 to reduce the chance of problems for players.  
- any savegame using the nightly build of FIRS may break :o



------------------
2 Downloading FIRS
------------------

If you don't want to compile FIRS yourself, you can download precompiled nightly
versions from http://mz.openttdcoop.org/bundles/firs/.
Nightly versions are made available on a regular basis. Once we reach a stable
release, you can get those from the same address as well, or via the OpenTTD
built-in download manager.



------------
3 Using FIRS
------------

Obviously you need to add it to the game first. We're not explaining that here,
go read the OpenTTD manual at http://wiki.openttd.org/NewGRF.

FIRS shouldn't be used with other industry sets active. FIRS will disable itself
if an incompatible industry set is detected, but this detection will only work
for industry sets known at the time of the FIRS release. There's a possibility
that FIRS will be compatible with other industry sets in the future.

* Vehicle Set Support *

Furthermore you need a vehicle set that supports the FIRS cargos. Any vehicle
set with proper Cargo Classes support should do that by default. The OpenTTD
vehicles will not be able to transport all FIRS cargos. The following sets
available from the OpenTTD built-in download manager are known to support FIRS:
- Train Sets:
  - 2cc Train Set
  - North American Renewal Set (NARS) 2
  - Old Wagons with New Cargos 1.1
  - UK Renewal Train Set v3
  - DB Set XL (with FIRS extension)
  - UK Railway Set (UKRS2)
- Road Vehicle Sets:
  - eGRVTS v1.0
  - HEQS (Heavy Equipment Set) 0.5b
- Ship sets
  - FISH
  - New Ships (partial support)
- Plane Sets
 - AV8
 - GeneralAv8ion
 - Plane Set

(Contact a FIRS developer to have your own set listed here)


* Parameters *
Parameter 1. Economy setting: unfinished, may only be set to 0


Parameter 2. Primary production change:
	
  0 = no production decreases (ever); production increase chance if supplies delivered monthly (default)
	
  1 = production decrease chance if no ENSP; production increase chance if supplies delivered monthly.


Parameter 3. Industry Closure / Openings.  Bit map (add the numbers to get the required setting.

  0 = no primary or secondary industry closures (default)
  1 = allow primary industry closure
  2 = allow secondary industry closure	
  3 = allow primary and secondary industry closure (combination of 1 + 2) 
	
  4 = no industries open during game (unfinished, doesn't work yet)


  
* Boosting Primary Production *

Primary industries produce raw materials, e.g. 
- mines, farms, junk yard, oil wells, oil rig etc.



Many FIRS primary industries accept Engineering Supplies or Farm Supplies.  
They will only increase production if the correct supplies are delivered.


Every month there is a chance of a production increase if at least 1t of the 
correct supplies are delivered.  
Only 1t of supplies is required - delivering more than 1t of supplies will 
not make a production increase more likely.  

Small vehicles are best for delivering supplies. 
(transfer orders are recommended, with a large vehicle dropping supplies at
a station to be delivered by small vehicles).



If parameter 1 is set to 0, primary industry production will never reduce.  


If parameter 1 is set to 1, there is a chance that a primary industry will 
reduce production if no supplies are delivered in a month.  
If the industry is producing a high level of output, there is a greater chance
of a production decrease.



---------------------
4 Errors and warnings
---------------------

FIRS is not compatible with all other NewGRFs out there. Great care has been taken
to locate all incompatible NewGRFs, but not all may have been found.
In case FIRS is able to detect an incompatible NewGRF, it will issue an error (and
disable itself) or issue a warning. Below you will find an explanation of possible
errors and warnings.


E00: FIRS requires...
FIRS requires a reasonably recent version of OpenTTD, as listed in the error
message, and cannot work on older versions due to missing features.
Either upgrade your OpenTTD to at least on of the versions indicated in the error
message or don't use FIRS.

E01: Incompatible set...
FIRS has detected an other NewGRF that conflicts with FIRS' features and
possibilities. If you want to use FIRS, you have to remove the indicated NewGRF
from the active NewGRF files list. After doing so, you might receive the same 
warning but then for a different NewGRF. Continue to remove all NewGRFs indicated
until the error messages disappear.

E02: Incompatible parameter...
Some NewGRFs have parameter options that are incompatible with FIRS. To use FIRS,
you have to change the parameter settings of the NewGRF idicated in the error
message. What parameter to change to what value is indicated as well.

E03: Incompatible version...
Only more recent versions of the NewGRF indicated are compatible with FIRS. If you
want to use the indicated NewGRF together with FIRS, you should upgrade that NewGRF
to at least the version indicated.

E04: Incompatible version...
Only more recent versions of the NewGRF indicated are compatible with FIRS. If you
want to use the indicated NewGRF together with FIRS, you should upgrade that NewGRF
to at least the version indicated. The difference with an E03 error is that you also
need at least OpenTTD r20675.


W01: Possible set incompatibility detected...
If you receive this warning, FIRS is not sure if the NewGRF indicated is compatible
or not. You need to check the version of the NewGRF indicated manually. If you 
continue to use an incompatible NewGRF together with FIRS, you may not complain
about possible problems in FIRS at the penalty of never being allowed to use FIRS
again.



----------------
5 Compiling FIRS
----------------

The FIRS source is available in a Mercurial repository and is available through
http://mz.openttdcoop.org/hg/firs. E.g. use hg clone
http://mz.openttdcoop.org/hg/firs to get yourself a copy.

In order to compile FIRS from source you need at least r2125 of NFORenum and
GRFCodec or the latest stable versions of those tools (at the moment v3.4.6
resp. v0.9.10). Using any recent version inbetween will most likely fail to
compile FIRS correctly.
Place both renum and grfcodec in the FIRS main directory or your system's PATH
environment variable and run the makefile:
   make                  Compile the FIRS newgrf
   make bundle           Compile and create a tar with directory structure and
documentation
   make install          Compile, tar and install to OpenTTD data directory
(either guessed by the makefile or to be configured in Makefile.local)
   make release          Compile and tar/zip with version information for
shipping
   make release-install  Compile, tar/zip with version information and install
tar to data directory

either 'make', 'make install', 'make bundle' or 'make release'. There's more
options, but these are probably sufficient for you to know.



-----------------
6 The FIRS NewGRF
-----------------

If you want to check the integrity of your grf or check whether your
self-compiled grf is the the same as it should, compare the values shown ingame
in the NewGRF selection window with these values:

GRF Name : FIRS Industry Replacement Set nightly-r1371M
GRF ID   : F1 25 00 04

This version of FIRS is created using repository version 1371



----------------
7 FIRS Web Links
----------------

  FIRS Website: http://tt-foundry.com/sets/FIRS/schema/industries
  Information about industries and cargos for both users and set authors.
   
  Project Page: http://dev.openttdcoop.org/projects/firs
  Source repository and issue tracker.
  
  General Discussion: http://www.tt-forums.net/viewtopic.php?t=44177
  Discussion of the FIRS releases. Talk about it's features, discuss bugs and
ventilating your ideas.
  
  Development Discussion: http://www.tt-forums.net/viewtopic.php?t=41607
  Follow the latest development.
 


--------------
8 FIRS License
--------------

    FIRS Industry Replacement Set - Full industry replacement set for OpenTTD
    Copyright (C) 2009  andythenorth, FooBar, Zephyris and others

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
