Snow Line Mods
--------------

This version: Snow Line Mod  nightly-r1M

Contents:

1 About
2 License
3 Credits



-------
1 About
-------

This NewGRF sets the snow line to height 1.

Name of this Repo: Snow Line Mod  nightly-r1M
GRF_ID:            "IB" 01 05
MD5 sum:           f3b7b068d18ca1ef2a555e66f7ec9deb snowlinemod.grf

Repository version: 1



---------
2 License
---------

The Snow Line Mod is written by Ingo von Borstel (aka planetmaker) and is free to use for anyone under the terms of the GNU Pulic License v2 or higher. See license.txt. 

The source code can be obtained from the #openttdcoop DevZone at http://dev.openttdcoop.org/projects/snowlinemod or via mercurial checkout
hg clone http://dev.openttdcoop.org/projects/snowlinemod



---------
3 Credits
---------

Coders: Ingo von Borstel (aka planetmaker)

Special thanks to #openttdcoop and especially Ammler who provides and works a lot on maintaining the Development Zone where this repository is hosted and who also frequently gives much valuable input. Thanks also to all the NewGRF authors whose NewGRFs can be my playground for this project.
