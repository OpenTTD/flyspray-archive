                ******************************
                *    Renewed City Growth     *
                *  A GameScript for OpenTTD  *
                ******************************


Usefull URL's:
- forum topic: http://www.tt-forums.net/viewtopic.php?f=65&t=69827
- last stable version: http://bananas.openttd.org/en/gs/
- public repository: http://dev.openttdcoop.org/projects/gs-rcg


Content:
* 1. How the script works
* 2. Settings
* 3. Requirements
* 4. License
* 5. Credits
* 6. Contact


1. How the script works

Renewed City Growth (RCG) is a game script which changes the way towns
grow in OTTD. Various cargo requirements are defined - monthly - for
each town and towns only grow if those requirements are - partially or
completely - satisfied. RCG supports several industry sets: Baseset
industries, FIRS industries, ECS industries.

The script only defines requirements for towns who are exchanging
passengers (meaning that a delivery of passengers coming from a town
is detected). Unless a town exchange passengers, it is not monitored
and you will not see any cargo requirement. The check is done
monthly. When a town stops exchanging passengers for six month, it
gets out from the list of monitored towns.

If passenger delivery is detected, the script defines some cargo
requirements for the ongoing month. Cargo requirements are not defined
by cargo types but by more general cargo categories, each of them
containing several cargo types. For example, cargo category 1 contains
Passengers and Mail cargo types. To achieve a cargo category
requirement, you can deliver to the town any of the category's cargo
type (for category 1, you can deliver indifferently Passengers or
Mail). If you delivery more cargo than necessary, the surplus is
stockpiled to be consumed next month (towns can stockpile a quantity
of 10 * cargotype requirement).

Depending on the used industry set, there are 3 or 5 categories. To
have an exact list of cargo categories, you can check the cargo.nut
file, where categories are defined. A comprehensive ingame list of
categories cargotypes has not yet been implemented. It will come in
some next release. Here are the basic categories:
For baseset industries (all climate):
- Cat 1: Passengers and Mail
- Cat 2: General goods (includes food and goods)
- Cat 3: Industrial materials (includes coal, wood, grain...)
For FIRS and ECS:
- Cat 1: Passengers and mail (includes also ECS' Tourists)
- Cat 2: General food (includes: food, alcohol, fruit...)
- Cat 3: General goods (includes: goods, petrol, building material...)
- Cat 4: Raw industrial material (includes: coal, oil, wood...)
- Cat 5: Transformed industrial material (includes: chemicals, lumber,
  manufacturing supplies, farm supplies...)

Cargo category requirements increase relatively to town population, in
two ways:
- for each cargo category, requirement increases linearly depending on
town size. The bigger a town is, bigger is the requirement for a given
category.
- each category starts being required only on a defined town
size. Passengers and mail are required whatever the town's size is,
while General food cargos are required only for towns bigger
500. General goods cargos, for towns bigger than 1500.
Hence, little towns only need Cat.1 cargos (Passengers and mail) to
grow, while towns with at least 500 habitants also need - increasingly
- food. When cities grow more, other categories come in play. That
means, that in the end, you can only expect to have a full - and long
term - city growth when developing some local industry, to which
deliver raw and transformed industrial materials. For details about
each industry set watch at cargo.nut.

The informations that the script gives are:
- under each town name, a string indicates the actual town growth
rate, only for the monitored towns; the number indicates how many days
will pass between each town expansion
- in townboxes, detailed informations about cargo requirements are
given for each category, in the form:
*category: actual goal / last month supply / stockpiled cargo.

Each month, for each town, a new town growth rate is recalculated. Its
level depends on the part of required cargo which have been
supplied. If you deliver all the required cargo, you will have the
maximum growth rate for a town (its maximum growth rate depends on its
size). If you deliver only a part of cargo, growth rate will be
lower. If you only deliver 50% of the requirements, town growth rate
is arbitrarily set to 10000. If you deliver a larger part of
requirements, the town growth rate increases exponentially. Hence, the
town growth rate is at the same time progressive and exponential.

The town growth rate calculated each month for a town is not used as
it: the script uses a moving average of the town growth rates from the
last 8 months. This feature allows to avoid big gaps in town's growth
rate. Changes in towns growth rates are smoothened and progressive.

Finally, note that towns data (goals, supplies, stockpiles, growth
rates...) are saved, so that you can safely reload the game without
losses.

The script has been tested as much to avoid any bugs. If however you
find any, please report the issue at the following bugtracker, where
you can also make suggestion to improve the script:
http://dev.openttdcoop.org/projects/gs-rcg/issues/new

Have fun !


2. Settings

- "Difficulty level": a general factor for calculating cargo
  requirement. The higher it is, the higher are cargo requirements.
- "Debug": allows to define the amount of informations which are
  printed in GS' log. Set it to 3 if you want check details about
  calculations.


3. Requirements

- OpenTTD, v. 1.4.x or trunk.
- GS SuperLib, v. 38 (you can find that on BaNaNaS, also accessible
  through OTTD's "Online Content").
- Industry sets: you can use Baseset (all climates), FIRS (all
  economies) or ECS (only tested again all vectors together). Using
  RCG with any other unsupported industry set may result in odd - or
  unstable - behaviours.


4. License

Renewed City Growth is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License as
published by the Free Software Foundation, version 2 of the License
(see file license.txt).


5. Credits

Author: keoz
Thanks to:
- kormer, whose code was the starting point of this.
- planetmaker, Zuu and krinn, who helped a lot, by helping to set up a
  public repository, answering to my numerous questions, spotting out
  bugs or suggesting code optimizations ;).


6. Contact

Write at: keikoz at free.fr
