    ........................................................................
 .:c:;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:c:.
 ;l.  ,,,,,,,,.                                                             .l;
 c:  ;xxkKN0kxd'                                                             :c
 c:     .oXc  .,.   ..   .::,.  .,:;.     .::,.   .,:;:.    .,::.   .,,,,,.  :c
 c:      oXc  :Kd. :Xd.,00ddkc ;K0dxXx. .xKxd00;  OWKkKXc  ;OkldKx..cddONK,  :c
 c:      oXc  .OX;.OK'.0X,    .0X' .oKl.lXo  'KK. ON, ;Xk..0Xc',0N;   '00,   :c
 c:      oXc   :NOdKo .XK.    .XK.  :Xd.dN:   0N' ON' ,Xk.,XNxdddd'  ,0K,    :c
 c:      oXc   .kWW0. .0X,    .0K'  oKl.lXo  .0K. ON' ,Xk..KK'   .  ;KO.     :c
 c:      oX:    ,XNc   :KKookl.:K0oxXk. .kXxo00:  ON' ,Kk. :00olkO',KWOool.  :c
 c:      .,.    ;Kk.    .,c:,.  .;c:'     ':c;.   ',   ,'   .;cc;. .,;;;;,.  :c
 c:            .0K,                                                          :c
 ;o.           .:,                                                          .o;
  ,::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::,
   ''''''''''''''''''''''''''''''''''''''''''' http://www.tycoonez.com ''''''

   Informace
   =========

             Název souboru: 
                    GRF-ID: 
                     Verze: 
                   Grafika: 
                       Kód: 

   Instalace
   =========

    Soubor vyžaduje unifont.grf (minimální verzi v0.8), který musí být
    aktivní. Soubor unifont.grf je dostupný na http://ttd.tycoonez.com/


   Konfigurace
   ===========

      Copyright © 2006 Tycoonez.com:munity http://ttd.tycoonez.com/
