OpenGFX+ Trees 0.2.2
GRF ID: "Frx" 06

	A graphic replacement set for trees for OpenTTD (from version 0.3.5 or, and I recommend, much much later)
and TTDPatch (2.6 r2334 or later). This NewGRF currently contains graphics for temperate, sub-arctic and some
sub-tropical trees. Toyland trees will be considered if needed.

Parameters:
	1st Parameter - Forest Candidates
		0 - Dense
		1 - Loose
		2 - Loose with two types of trees
		3 - Brown
	2nd Parameter - Roadside Tree Candidates
		0 - Use Default
		1, 2, 3, 4, 5 - 5 types of roadside tree available
	Parameters 4 to 22 - Tree Exclusion
		These parameters correspond to each treetype found in this newgrf. A value of 0 disables the tree, 1 enables.
		All trees are enabled by default. For sub-arctic climate, parameters 4 to 11 are used for dry trees, parameters
		12 to 19 for snowy trees and 20 to 22 are ignored. For sub-tropical climate, parameters 4 to 5 are used for
		2 cactus trees and the rest for tropical trees. (There's just three tropical trees for now)

	Notes: When updating running games from version 0.1	to 0.2.0, you'll need to reload the GRF to enable all trees
		or reset parameters if that option is available. (Not needed for version 0.1 to 0.2.1 or later)
			For OpenTTD users, I recommend getting the latest nightly, or at the least, versions not older
		than r20766 to take advantage of the new parameter GUI to make setting parameters a lot easier.

Tools Used:
	Grfcodec and NFORenum for compiling and debugging
	GIMP for drawing sprites
	Notepad++ for coding NFO

Thanks to:
	- planetmaker and Ammler for setting me up at the OpenTTD Devzone and for their valuable advice
	- the TTD community for their continuing support
	- the developers of TTDPatch and OpenTTD for keeping this game alive
	- and to the origin of this timeless game, TTD

Version History:
	- 0.2.2
		- swapped tree activation values back
		- added one more tropical tree
	- 0.2.1
		- swapped tree activation values (0 with 1)
		- added a few sub-tropical trees
		- added, swapped and edited more tree graphics
	- 0.2.0 [GNU GPL v2]
		- change license from GPL v3 to GPL v2
		- added capability to exclude treetypes
		- added and edited more tree graphics
	- 0.1
		- added more tree graphics
	- Alternative Replacement Trees (Test Version) [GNU GPL v3]

Contact:
	e-mail: froikz@yahoo.com
	devzone: http://dev.openttdcoop.org/projects/ogfx-trees
	forums: http://www.tt-forums.net/viewtopic.php?f=26&t=49911&start=0

Copyright � 2010 Froix
[see file license.txt]

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write to the Free Software Foundation, Inc.,
	51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.