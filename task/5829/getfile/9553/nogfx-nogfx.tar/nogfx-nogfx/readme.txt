NoGFX Readme - A base graphics set without graphics

==============================
Current Version: NoGFX nogfx-r475
==============================

Contents
0 About NoGFX
1 Downloading and Installing NoGFX
2 Reporting bugs and Contributing
3 Building of NoGFX
    5.1 Notes for package maintainers
4 License
    6.1 Obtaining the source
5 Credits



0 About NoGFX
===============

NoGFX is an open source base graphics set for OpenTTD, but without actual
graphics. It is intended to be distributed with OpenTTD, so new users can
start the game and then download OpenGFX via the content-download feature.

NoGFX is based on OpenGFX and the little GUI features it contains are from 
OpenGFX as well.

The reason for the existance of NoGFX is the greatly reduced filesize compared
to full-featured base graphic sets. This allows for easier distribution with
OpenTTD due to reduced file size and prevents users upgrading OpenTTD regularly
having to download a full base graphics set with OpenTTD over and over again
which they already have.



1 Downloading and Installing NoGFX
==================================

If NoGFX didn't come with your version of OpenTTD, there's no real point downloading
and installing it manually. Your better of getting OpenGFX instead.



2 Reporting bugs and Contributing
=================================

If you spot any grapical bugs or glitches in the available graphics, please let
us know via the OpenGFX bug tracker
http://dev.openttdcoop.org/projects/OpenGFX/issues
Please make sure that you're using the latest available version before reporting 
a bug. You can check the Issue Tracker to see if the bug you've found is already 
reported (or fixed!).



3 Building NoGFX
=========================================

The NoGFX source is available in the OpenGFX Mercurial repository or as gzip'ed tarball.
You can do an anonymous checkout from http://mz.openttdcoop.org/hg/OpenGFX ,
e.g. using
   hg clone http://mz.openttdcoop.org/hg/OpenGFX or obtain the tarball from
http://bundles.openttdcoop.org/OpenGFX/releases.
   
Prerequisites to building NoGFX:
- mercurial (only when not building from a tarball, available from
http://mercurial.selenic.com/wiki/Download?action=show&redirect=BinaryPackages)
- gcc (the pre-processor is needed)
- md5sum (linux, mingw) or md5 (mac)
- nforenum r2281 or better (available from http://www.openttd.org/download-nforenum)
- grfcodec r2245 or better (available from http://www.openttd.org/download-grfcodec)
- some gnu utils: make, cat, sed, awk
and you might additionally want a text editor of your choice and a graphics
programme suitable to handle palettes. 

On Windows: we advise not to build on Windows. You can set up a virtual linux 
environment and use the instructions instead.

On Linux: your system should already have most tools, you'll probably only need
nforenum, grfcodec and mercurial available from the source mentioned above. For
installation instructions concerning mercurial refer to the manual of your
distribution.

On Mac: Install the developers tools and get grfcodec and nforenum from the
source mentioned above. Mercurial is easiest installed via macports: sudo port
install mercurial

The use of mercurial is strongly encouraged as only that allows to keep track of
changes.

Once all tools are installed, get a checkout of the repository and you can build
NoGFX using make. The following targets are available:
- all: builds all grfs and the obg file
- install: build and then copy NoGFX in your OpenTTD data directory. Use
Makefile.local to specify a different path.
- clean: cleans all generated files
- mrproper: also cleans generated directories
- bundle_src: create a source tarball
- bundle_zip: create a zip archive of NoGFX
- bundle_bz2: create a bzip2 archive of NoGFX
- bundle_tar: create a tar archive of NoGFX
- check: checks the md5 sums of the built grf and obg files against those of
the official release versions

Given the usual case that you modify something within NoGFX and want to test
that, a simple 'make install' should suffice and you can immediately test the
changes ingame, if you selected the nightly version of NoGFX. Given default
paths, a 'make install' will overwrite a previous nightly version of NoGFX.
Mind to re-start OpenTTD as it needs to re-read the grf files.

3.1 Notes for package maintainers:
---------------------------------
It is advised not to provide NoGFX as a package. Consider providing OpenGFX
instead.



4 License
=========

NoGFX Graphics Replacement Set for OpenTTD Copyright (C) 2007-2009 OpenGFX
Authors (see below)

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License version 2 as published by the Free
Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free
Software Foundation, Inc., 1 Franklin Street, Fifth Floor, Boston, MA 02110-1301
USA.



5 Credits
=========

NoGFX is conceived by FooBar (Jasper Vries) and is maintained by the OpenGFX
developers:
* planetmaker (Ingo von Borstel)
* FooBar (Jasper Vries)
* Ammler (Marcel Gmür)

NoGFX contains graphics of the following OpenGFX graphic contributors:
(to be updated)

* Zuu (Leif Linse)
* Zephyris (Richard Wheeler)
* Varivar
* uzurpator
* Spaz O Mataz
* Soeb (Stanislaw Gackowski)
* skidd13 (Benedikt Brüggemeier)
* Rubidium (Remko Bijker)
* Roujin (Manuel Wolf)
* Red*Star (David Krebs)
* Raumkraut (Mel Collins)
* Purno (Mark Leppen)
* planetmaker (Ingo von Borstel)
* PikkaBird (David Dallaston)
* northstar2
* Mr. X
* mph (Matthew Haines)
* mb (Michael Blunck)
* molace (Zoltán Molnár)
* Lawton27 (Jack Lawton)
* LordAzamath (Johannes Madis Aasmäe)
* lead@inbox (Serge Saphronov)
* Jonha
* Irwe (Alexander Irwe)
* Gen.Sniper
* FooBar (Jasper Vries)
* erikjanp
* EdorFaus (Frode Austvik)
* drginaldee
* DJ Nekkid (Thomas Mjelva)
* DanMacK (Dan MacKellar)
* buttercup
* bubersson (Petr Mikota)
* Born Acorn (Chris Jones)
* Bilbo
* Ben_Robbins_ (Ben Robbins)
* athanasios (Athanasios Arthur Palaiologos)
* andythenorth (Andrew Parkhouse)
* AndersI (Anders Isaksson)
* Ammler (Marcel Gmür)

A detailed list of who worked on what is available in the file
docs/authoroverview.csv in the source repository. This file applies to the
full OpenGFX base graphics set of which NoGFX is just a subset.

Thanks go out to the guys at #openttdcoop for providing the source repository
and bug tracking services.
