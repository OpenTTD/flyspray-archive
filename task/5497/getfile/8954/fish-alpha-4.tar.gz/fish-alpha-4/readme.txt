FISH is Ships!
--------------
River boats, lake ships, coasters, hovercraft, hydrofoils and more in a wide range of capacities. Features lickable pixels in two company colours.

FISH provides a full set of passenger and freight ships.  FISH should work well with most cargo / industry newgrfs, including default industries, FIRS and PBI.

FISH ships first become available around 1870.

----------
Using FISH
----------

FISH requires OpenTTD v0.7 or above.  It will not work with TTDPatch, or OpenTTD prior to v0.7.

FISH vehicles are available in all the climates.

For latest information / releases, visit TT-Forums.
Release thread: 
	http://www.tt-forums.net/viewtopic.php?f=67&t=45435
Development thread:
	http://www.tt-forums.net/viewtopic.php?f=26&t=44613

---------
Authors
---------

Brought to you by andythenorth, with help from many, including Dan MacK, Emperor Jake, Frosch, lead@inbox, PikkaBird, Planetmaker and Yexo.
Makefile/build system: Ingo von Borstel (aka planetmaker)

Special thanks to #openttdcoop and especially Ammler who provides and works a lot on maintaining the Development Zone where this project is hosted and who also frequently gives much valuable input.

Special thanks to anyone I've forgotten :o

Contact me via the forums at http://tt-forums.net - username andythenorth

---------
License
---------

FISH is authored by andythenorth, the makefile by Ingo von Borstel (aka planetmaker) and released under the GNU General Public license v2 or later. See license.txt.

No warranty is provided.  Without limitation, the creators of the set cannot be held responsible for any consequences arising from download or use of the set or accompanying files.

The source code can be obtained from the #openttdcoop DevZone at 
	http://dev.openttdcoop.org/projects/fish 
or via mercurial checkout
	hg clone http://dev.openttdcoop.org/projects/fish

Building FISH requires NML and the Chameleon template library http://chameleon.repoze.org/docs/latest/

For integrity check:
Name of this Repo: FISH alpha-4
GRF_ID:            
MD5 sum:           498a9b1c844645b0c920261769c3b6db  fish.grf

Repository version: 942