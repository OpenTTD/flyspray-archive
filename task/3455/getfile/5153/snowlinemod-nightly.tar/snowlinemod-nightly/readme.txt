Snow Line Mods
--------------

This version: Snow Line Mod  nightly-r1M

Contents:

1 About
2 License
3 Credits



-------
1 About
-------

This NewGRF offers a snow line height which changes with the seasons.

Name of this Repo: Snow Line Mod  nightly-r1M
GRF_ID:            "IB" 01 05
MD5 sum:           7c67cec08cb1ed5c61cf5a0edfc82ec0 snowlinemod.grf

Repository version: 1

By default the snow line is at sea level in January and at height 6 in July. The snow line height can be adjusted via parameters 0 and 1:
Parameter 0: desired snow line height in January
Parameter 1: desired snow line height in July

The snow line height for the months in between is automatically adjusted linearily. 
E.g. if you want the snow line at level 3 in January and at level 9 in July, you set the parameters to 3 and 9 respectively. Also reversing
the values to simulate the Southern hemisphere is possible; e.g. to simulate New Zealand climate you'd set them to 9 and 3 respectively.

Be aware that not all graphics are snow-line aware and some assume a constant snow line. That is an issue with those graphics and out of 
scope of this newgrf. Use house and industry sets which support this feature. Default houses and industries are not aware of a changing snowline.

---------
2 License
---------

The Snow Line Mod is written by Ingo von Borstel (aka planetmaker) and is free to use for anyone under the terms of the GNU Pulic License v2 or higher. See license.txt. 

The source code can be obtained from the #openttdcoop DevZone at http://dev.openttdcoop.org/projects/snowlinemod or via mercurial checkout
hg clone http://dev.openttdcoop.org/projects/snowlinemod



---------
3 Credits
---------

Coders: Ingo von Borstel (aka planetmaker)

Special thanks to #openttdcoop and especially Ammler who provides and works a lot on maintaining the Development Zone where this repository is hosted and who also frequently gives much valuable input. Thanks also to all the NewGRF authors whose NewGRFs can be my playground for this project.
