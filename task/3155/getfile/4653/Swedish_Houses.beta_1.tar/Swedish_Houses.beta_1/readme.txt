﻿Swedish Houses is a town replacement set for TTDPatch and OpenTTD for temperate, arctic and tropic climates. The goal of this set is to replace all original TTD buildings and add extra ones with buildings found in Sweden. This beta version has only a few essential buildings, future versions will include a lot more. 
  
  The set features: 
* support for new industry sets (food acceptance in temperate, gas stations accepts fuel oil/petrol(cargo label "PETR"), hotels and stadiums accept and produce tourist(cargo label("TOUR")). 
* road sensitive graphics for some buildings. 
* support for both Swedish and English languages. 
  
  
Parameter options: none at the moment. 
  
Known bugs: none at the moment. 
  
Swedish Houses grf is licensed under the GNU General Public License version 2.0. For
more information, see the file 'COPYING'.


Credits: Drawing and design by Alexander "Irwe" Irwe. Coding by Antti "as" Silventoinen. 
Sprites used from Industrial stations renewal set and Total town replacement set. 
Also thanks to everyone at the community (they know who they are) for their help.