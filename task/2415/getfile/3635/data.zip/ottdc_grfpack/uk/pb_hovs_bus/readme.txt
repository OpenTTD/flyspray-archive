haec omnibus vobis sunt (HOVS) Bus Set for TTDPatch.

files with _d suffix are the DOS version.

v1.2 17/06/05
http://www.pikkarail.com/locomotion/
pikkabird@pikkarail.com