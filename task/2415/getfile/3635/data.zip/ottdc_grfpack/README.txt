Version 5 (2007-06-23)

This pack is supposed to provide our members and interested guest the GRFs 
which are used on our servers.

Not all GRFs are used simultanously on our servers. The needed GRFs will be 
loaded ''automatically'' if you enter a server.

Plese visit http://openttdcoop.ppcis.org/wiki/index.php/GRF for homepages, 
authors and credits of each GRF. 
Some GRFs have their own documentation and licence file. In this case, we packed 
these files into the dedicated folders. Please be aware of these files.


You are NOT allowed to redistribute this pack. 
If you haven't downloaded it from openttdcoop.ppcis.org, please inform us:
irc://irc.oftc.net/#openttdcoop
openttdcoop@ppcis.org

Index for static GRFs with their paths to include in openttd.cfg. These GRF's are 
optional and usually not included on the server itself (You don't have to use them, 
but some are really nice):
http://openttdcoop.ppcis.org/wiki/index.php/GRF_static_template