FISH is Ships!

River boats, lake ships and coasters in a range of attractive sizes from 15t to 1080t. Features lickable pixels in two company colours.
-----------------------------------

This version: FISH nightly-r390M

Contents:

* About
* Credits
* License
* Installation
* Usage


-------
About
-------

FISH requires OpenTTD v0.7 or above.  It will not work with TTDPatch, or OpenTTD prior to v0.7.

FISH should work well with most cargo / industry newgrfs, including default industries, FIRS and PBI.

For latest information / releases, visit TT-Forums.
Release thread: 
	http://www.tt-forums.net/viewtopic.php?f=67&t=45435
Development thread:
	http://www.tt-forums.net/viewtopic.php?f=26&t=44613


For integrity check:

Name of this Repo: FISH nightly-r390M
GRF_ID:            "AN" 01 01
MD5 sum:           11d41957672ecd38258c6a2160e7f8ed  fish.grf

Repository version: 390


---------
Credits
---------

Author: andythenorth
Additional graphics: lead@inbox, Dan MacK
Makefile/build system: Ingo von Borstel (aka planetmaker)

Special thanks to #openttdcoop and especially Ammler who provides and works a lot on maintaining the Development Zone where this project is hosted and who also frequently gives much valuable input.

Thanks to frosch for help with newgrf code and features.

---------
License
---------

This NewGRF is authored by andythenorth, the makefile by Ingo von Borstel (aka planetmaker) and released under the GNU General Pulic license v2 or later. See license.txt. 

The source code can be obtained from the #openttdcoop DevZone at 
	http://dev.openttdcoop.org/projects/fish 
or via mercurial checkout
	hg clone http://dev.openttdcoop.org/projects/fish



------------------------------
Makefile System - Installation
------------------------------

The Makefile system is intended for newgrf developers, and players who wish to compile the grf themselves.

This Makefile system is easiest to setup if you employ a certain directory structure for your NewGRF project. Clone this project and fill in your NewGRF content. Make sure to adopt Makefile.config to your needs.

Requirements for running this Makefile successfully:
	grfcodec
	renum
	gcc
	md5sum (or md5 on Mac)
	make
If you want to bundle the grf, you'll need additionally
	tar
	zip
	bzip2
Windows only:
On Windows systems this means that you'll need to install MinGW and MSys in order to obtain a posix compatible environment. Then the makefile can be called the very same way as it is on linux and mac systems. MinGW/MSys contain the above mentioned programmes (except renum and grfcodec of course) and can be obtained from http://www.mingw.org/ That site also features an excellent walk-through o how to install it.

If you use for OpenTTD data folder a non-default path or Windows with a non-English localization make sure to copy Makefile.local.sample to Makefile.local and edit the line with
	INSTALLDIR =
accordingly so that it shows the full path to your OpenTTD / TTDP data directory.



-----------------------
Makefile System - Usage
-----------------------

The Makefile offers different targets. A brief overview is given here:

all: 
This is the default target, if also no parameter is given to make. It will
simply build the grf file, if it needs building

bundle:
This target will create a directory called "<name>-nightly" and copy the grf
file there and the documentation files, readme.txt, changelog.txt and
license.txt

bundle_zip
This will zip the bundle directory into one zip for distribution

bundle_tar
This will tar the bundle directory into a tar archive for distribution or upload
to bananas

install:
This will create a tar archive (like bundle_tar) and copy it into the INSTALLDIR
as specified in Makefile.local (or the default dir, if that isn't defined).
Don't rely on a good detection of the default installation directory. It's
especially bound to fail on windows machines.

release*:
This target will basically do the same as the bundle* targets with one
difference: They are packed in a uniquely named directory, so that all different
release versions of this can be used in parallel in OpenTTD.

clean:
This phony target will delete all files which this Makefile will create

remake:
It's a shortcut for first cleaning the dir and then making the grf anew.
