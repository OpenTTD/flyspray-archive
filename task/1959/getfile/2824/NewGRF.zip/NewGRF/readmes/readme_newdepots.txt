New Modern Depots Version 2.0

By Gavin Dowland (Ameecher)

(C) 2006 Gavin Dowland

These are new depots to replace the default TT depots. It should work fine in both TTDP and OTTD. Version 2.0 is a depot without false doors painted on the rear, 2.1 is with the above doors.

**PLEASE DO NOT EDIT THIS .GRF AND DISTRIBUTE IT AS YOUR OWN***

This .grf is free for everyone to use and no-one should be charged for it's use. I allow distribution of it but please give me suitable credit.

Please take a look at my website: 
http://www.ameechergfx.ttdgraphics.com/

Thanks go to Dave Worley for helping create this