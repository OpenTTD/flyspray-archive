GRF-name: Combined Airport Set V0.5
Author: Skidd13
E-Mail: Skidd13@gmx.de

This GRF contains gfx owned not by the author himself, but he has the permission to use them. Every other gfx in this grf is drawn by the author.

PARAMETERS:
1st:
0 = no runway replacement
1 = Skidd13's light-grey
2 = Skidd13's medium-grey
3 = Andrex's dark-grey
4 = Born Acorn's light-grey
5 = Born Acorn's dark-grey
6 = Skidd13's full-grey

2nd:
0 = no big airport replacement
1 = Skidd13's
2 = Born Acorn's grey
3 = Born Acorn's red brick
4 = Andrex's control tower
5 = Rspeed fake-based

3rd:
0 = no small airport replacement
1 = Skidd13's

4th:
0 = no transmitter replacement
1 = Skidd13
2 = Skidd13 2d
3 = Andrex
4 = Born Acorn

5th:
0 = no helipad replacement
1 = Skidd13
2 = Andrex
3 = Born Acorn

6th:
0 = no fence replacement
1 = TTRS3 based fences
2 = no fences

CREDITS: (of included graphics by other artists)
runway:
	- #3 drawn by Andrex
	- #4, #5 drawn by Born Acorn
big airport:
	- Skidd13's
		- Control tower original by Mr. Hunt
		- Large terminal original by Rob
	- #2,#3 by Born Acorn
	- control tower by Andrex
transmitter:
	- #3 by Andrex
	- #4 by Born Acorn
helipad:
	- Skidd13's
		- Heliport "H" drawn by Born Acorn and included in RichK67' newairports
	- #2 by Andrex
	- #3 by Born Acorn

LICENSE:
You are allowed to redistribute the grf, but keep this readme with it. If you want to use sprites of the grf just ask me or the autor if I didn't drew the sprite. I'll probably never say no. But keep in mind:
Give credit where credit is due.

BIG THANKS
- to all the artists
- to DaleStan for his help with my NFO coding

Have fun with it.

Skidd13
