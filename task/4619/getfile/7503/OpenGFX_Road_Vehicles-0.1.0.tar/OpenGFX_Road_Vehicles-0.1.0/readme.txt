﻿OpenGFX+ Road Vehicles
-----------------------------------

Version: OpenGFX+ Road Vehicles 0.1.0

Contents:

1 About
2 Quickstart
3 Build requirements
4 Building from source
  4.1 Speed issues
5 License
6 Credits



-------
1 About
-------

OpenGFX+ Road Vehicles enhances default road vehicles to be able to
handle new cargos, and extends them with new road vehicles and trams.
Designed to match the OpenGFX style.

Name of this Repo:  OpenGFX+ Road Vehicles 0.1.0
Repository version: 77
GRF_ID:             "OG+" 02
MD5 sum:            b42b3dd63720c1f2483b357575736087  ogfx-rv.grf



--------------
2 Quickstart
--------------

Copy the grf file in your data dir and activate it in OpenTTD. You can also
use 'make install' (see section 4).



--------------------
3 Build requirements
--------------------

Requirements for building this NewGRF successfully:
	NML
	gcc
	md5sum (or md5 on Mac)
	make
	mercurial (recommended)
	python (recommended)

If you want to bundle the grf, you'll need additionally:
	tar
	zip
	bzip2
	unix2dos (optional)

Windows only:
On Windows systems this means that you'll need to install MinGW and MSYS
in order to obtain a POSIX compatible environment. Then the makefile can
be called the very same way as it is on Linux and Mac systems.

MinGW/MSYS contain the above mentioned programmes and can be obtained
from http://www.mingw.org/ That site also features an excellent
walk-through on how to install it.

If you use a non-default path for OpenTTD data folder or Windows with a
non-English localization make sure to copy Makefile.local.sample to
Makefile.local and edit the line with
	INSTALLDIR =
accordingly so that it shows the full path to your OpenTTD / TTDP data
directory.



----------------------
4 Building from source
----------------------

The Makefile offers different targets. A brief overview is given here:

all:
	This is the default target, if also no parameter is given to
	make. It will simply build the grf file, if it needs building.

depend:
	Re-run the dependency check. Usually not manually needed.

docs:
	Build the documentation files.

bundle:
	This target will create a directory called "<name>-nightly" and
	copy the grf file there and the documentation files, readme.txt,
	changelog.txt and license.txt.

bundle_zip
	This will zip the bundle directory into one zip for distribution.

bundle_tar
	This will tar the bundle directory into a tar archive for
	distribution or upload to bananas.

bundle_src
	Creates a source bundle.

install:
	This will create a tar archive (like bundle_tar) and copy it
	into the INSTALLDIR as specified in Makefile.local (or the
	default dir, if that isn't defined). Don't rely on a good
	detection of the default installation directory. It's
	especially bound to fail on windows machines.

distclean:
	This phony target cleans everything from a source bundle which
	wasn't shipped.

clean:
	This phony target will delete all files which this Makefile will
	create.

mrproper:
	This phony target will delete also all directories created by
	different Makefile targets.

remake:
	It's a shortcut for first cleaning the dir and then making the
	grf anew.

addcheck:
	Check whether there are some files required but not part of the
	repository.

check:
	Check the md5sum of the built newgrf against the supplied md5sum
	(Intended to be used when building from tar balls).



4.1 Speed issues
----------------

A note concerning the speed of the makefile:
It seems that the required tools using MinGW and / or msys are thoroughly
slow on windows. A few example run times for OpenGFX, same processor type
(both core 2 duo, 2.26GHz for the windows machine, 2.0 GHz for the OSX
machine). Note that the values given are the 'real' time. Even though
this varies more and is dependent on the processor load, that's what you
have to wait for; the 'user' times are quite low on the windows machine
(~16s), but that by no means reflects the build time. Times are from
OpenGFX r539 with makefile r199.

DEP_CHECK_TYPE         windows               bash native
                 native       in VM            (OSX)
none            1m23.360s      -             0m32.781s
mdep            1m54.484s   0m30.164s        0m33.807s
normal          2m37.857s      -             0m36.528s



---------
5 License
---------

This NewGRF was written by José Ángel Soler Ortiz (aka Terkhen) and 
Ingo von Borstel (aka planetmaker) and is free to use for anyone
under the terms of the GNU Public License v2 or higher. See
license.txt.

The source code can be obtained from the #openttdcoop DevZone at
http://dev.openttdcoop.org/projects/ogfx-rv or via mercurial
checkout
hg clone http://hg.openttdcoop.org/ogfx-rv



---------
6 Credits
---------

Authors: Terkhen, planetmaker

Graphics:
	Trams:                   DanMacK
	Temperate trucks:        Zephyris
	Sub-arctic trucks:       Zephyris
	Sub-tropical trucks:     Zephyris
	Toyland buses:           DanMack
	Toyland trucks:          DanMack
    
Special thanks to #openttdcoop and especially Ammler who provides and
works a lot on maintaining the Development Zone where this repository is
hosted and who also frequently gives much valuable input. Thanks also to
Alberth, Yexo, Rubidium and Ammler who frequently give valuable
input in form of advice and patches to this project. Last but not least
thanks to all the NewGRF authors whose NewGRFs can be my playground for
this project.
