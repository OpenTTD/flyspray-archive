OpenGFX+ Trains
-----------------------------------

This version: OpenGFX+ Trains 0.2.5

Contents:

1 About
2 Quickstart
3 This NewGRF in detail
  3.1 Parameters
  3.2 Rolling stock
4 Building from source
  4.1 Requirements
  4.2 Obtaining the source
5 License
6 Credits



-------
1 About
-------

OpenGFX+ Trains enhances the rolling stock. Designed to work match
OpenGFX style

Name of this Repo:  OpenGFX+ Trains 0.2.5
Repository version: 240
GRF_ID:             "OG+" 02
MD5 sum:            283c7e8d8017b8c6c9b3da9cdaf45a8c  ogfx-trains.grf



--------------
2 Quickstart
--------------

Copy the grf in your data dir and activate it.



-----------------------
3 This NewGRF in detail
-----------------------

3.1 Parameters:
---------------
Choice of rolling stock:
  This NewGRF allows you to select via parameter which engines shall be
  provided. You can choose from andy of the four climates, all engines,
  none or autmatically choosing those which are designed for the map's
  climate (default).

Purchase and running costs can be configured:
  You can either manuall select the level of running and purchase costs
  with respect to the default values or let the NewGRF automatically con-
  figure these costs. In the presence of other rail NewGRFs it will try
  to adjust these costs in order to match the other set(s). It will try
  to match in the following order (last set wins):
  - NARS2 (North American Renewal Trainset, grfID 44440302)
  - UKRS2 (UK Renewal Trainset (grfID 44440111)
  - Tropical Refurbishment Set (grfID 44444040
  - 2cc Trainset v2 (grfID 27711003)
  - Japanese Trainset v2 (grfID 535A0D00)
  - Swedish Trains (grfID 41490006)

3.2 Rolling stock
----------------
The number of wagons has been reduced with respect to the default
wagons, but they can now be refitted, so that for every cargo within
the game you'll find at least one wagon which supports transporting it:

- passenger wagon:
    passengers and tourists
- mail wagon:
    mail
- armoured wagon:
    valuables, gold, diamonds
- bulk wagon:
    coal, iron ore, bauxite, cement, copper ore, gravel, sand, clay, grains,
    maize, wheat, sulphur, fertilizer, scrap metal, fruit, 
    fruit & vegetables, toffee, sugar, cotton candy, sugar beet
    lumber (wood chips), cereal
- piece goods wagon:
    goods, food, paper, fruits, fruit + vegetables, farm supplies,
    engineering supplies, manufacturing supplies, wool
- lifestock wagon:
    livestock
- refrigerator wagon:
    fish, food, fruits, fruits and vegetables, milk
- flatbed wagon:
    wood, lumber, metal, steel, glass, goods, manufacturing supplies,
    farm supplies, engineering supplies, batteries, fizzy drinks, bubbles
- tank wagon:
    oil, fuel oil, water, milk, rubber, dyes, chemicals, cola

Some wagons change their look after a certain date, new wagons will look
  different from the older wagons. By default this transition year is
  for rail wagons 1970.

----------------------
4 Building from source
----------------------

Requirements for running this Makefile successfully:
	NML
	gcc
	md5sum (or md5 on Mac)
	make
    mercurial (recommended)
    python (recommended)
If you want to bundle the grf, you'll need additionally
	tar
	zip
	bzip2
	unix2dos (optional)
Windows only:
On Windows systems this means that you'll need to install MinGW and MSys
in order to obtain a posix compatible environment. Then the makefile can
be called the very same way as it is on linux and mac systems.
MinGW/MSys contain the above mentioned programmes (except renum and
grfcodec of course) and can be obtained from http://www.mingw.org/ That
site also features an excellent walk-through o how to install it.

If you use for OpenTTD data folder a non-default path or Windows with a
non-English localization make sure to copy Makefile.local.sample to
Makefile.local and edit the line with
	INSTALLDIR =
accordingly so that it shows the full path to your OpenTTD / TTDP data
directory.

If the Makefile is too slow, you may try different dependency checks or
skip those completely. Available options for dependency generation are:
mdep:   uses a python script. Default when used in a hg repository
normal: uses gcc and bash to scan for dependencies
none:   disable the dependency generation (mostly)
Makefile.local allows to choose the method via the declaration of
DEP_CHECK_TYPE.

The Makefile offers different targets. A brief overview is given here:

all:
	This is the default target, if also no parameter is given to
	make. It will simply build the grf file, if it needs building

depend:
	Re-run the dependency check. Usually not manually needed.

docs:
	Build the documentation files

bundle:
	This target will create a directory called "<name>-nightly" and
	copy the grf file there and the documentation files, readme.txt,
	changelog.txt and license.txt

bundle_zip
	This will zip the bundle directory into one zip for distribution

bundle_tar
	This will tar the bundle directory into a tar archive for
	distribution or upload to bananas

bundle_src
	Creates a source bundle

install:
	This will create a tar archive (like bundle_tar) and copy it
	into the INSTALLDIR as specified in Makefile.local (or the
	default dir, if that isn't defined). Don't rely on a good
	detection of the default installation directory. It's
	especially bound to fail on windows machines.

distclean:
	This phony target cleans everything from a source bundle which
	wasn't shipped.

clean:
	This phony target will delete all files which this Makefile will
	create

mrproper:
	This phony target will delete also all directories created by
	different Makefile targets

remake:
	It's a shortcut for first cleaning the dir and then making the
	grf anew.

addcheck:
	Check whether there are some files required but not part of the
	repository.

check:
	Check the md5sum of the built newgrf against the supplied md5sum
	(Intended to be used when building from tar balls)

4.1 Requirements
----------------

In order to build this newgrf from source you need:
- python 2.5+ with yacc, pil modules installed
- NML r1323 or newer
- make 3.80+
- gcc as pre-processor
- some small shell tools: cat, sed

and optionally:
- unix2dos possibly for conversion of the documentation files
- tar for creating bundles
- zip for creating bundles

4.2 Obtaining the source
----------------------

The source code can be obtained from the #openttdcoop DevZone at
http://dev.openttdcoop.org/projects/ogfx-trains or via mercurial
checkout
hg clone http://hg.openttdcoop.org/ogfx-trains



---------
5 License
---------

OpenGFX+ Trains trainset for OpenTTD and TTDPatch
Copyright (C) 2010-2011 by the OpenGFX+ Trains team (see below)

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License version 2 (or, at your discretion,
any later version) as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along with
this program; if not, write to the Free
Software Foundation, Inc., 1 Franklin Street, Fifth Floor, Boston, MA 02110-1301
USA.



---------
6 Credits
---------

Authors: 
    Lead programmer:            Ingo von Borstel (aka planetmaker)
    General coding:             Terkhen
Graphics: 
    Toyland rail wagons:        molace
    Temperate rail wagons:      DanMacK, Uzurpator, Zephyris, molace
    Tropical rail wagons:       DanMacK, Uzurpator, Zephyris, molace
    Arctic rail wagons:         DanMacK, Uzurpator, Zephyris, molace

    Single trains and consits:
        Turner Turbo train:     DanMacK
        Flatbed wagon ENSP      Zephyris
    Cargo sprites:
        ENSP, FMSP, VEHI:       andythenorth

Translations:
    Chinese (traditional)       2006TTD
    Croation:                   Voyager1
    Dutch:                      Hirundo
    English:                    planetmaker
    French:                     peetleouf
    Norwegian Bokmal:           DJNekkid
    Serbian:                    etran
    Swedish:                    AndersI
    
Special thanks to #openttdcoop and especially Ammler who provides and
works a lot on maintaining the Development Zone where this repository is
hosted and who also frequently gives much valuable input. Thanks also to
Alberth, Terkhen Yexo, Rubidium and Ammler who frequently give valuable
input in form of advice and patches to this project. Last but not least
thanks to all the NewGRF authors whose NewGRFs can be my playground for
this project.
