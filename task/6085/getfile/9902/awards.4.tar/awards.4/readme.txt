Awards (c) krinn@chez.com, release under GNU/GPLv2+ (see the license.txt)

The Reward rules :
Both rewards use a base money amount for money operation, that "BaseMoney" is x * LoanInterval (where x is configurable in the script option) : per default 1

* 1 reward is a periodic one (disable per default): companies cannot loose money with this one, it have two usage :
- Gives a bit of money to boost companies that lead the rank table
- Balance the other reward bad effect (as this one takes money)
It's pretty simple :
The company rank 1st gets 100% of BaseMoney
The company rank 2nd gets the percent of points from the 1st company of BaseMoney : so if 1st company have 130 points, 2nd company have 90 points and BaseMoney is 10000 : 1st company takes 10000, 2nd company takes 90 / 130 * 10000 = 6923.... And another one with 40 points : 40 / 130 * 10000 = 3000

* And the 2nd reward is gave to any companies that reach an amount of points (this one is per default enable, to spice things), per default the amount is set to 100 but it's also configurable :
When a company reach 100 points : BaseMoney is taken from all other companies and add to its account : So with 5 companies playing : 4 companies loose 10000, 1 company gets 40000.
This one can be a serious treat for new company sure, but it could be balance by enabling the other one or disabling it.



Building your own award :
To make a new award, you need to add it to english.txt file following this format
STR_KEY_10		: Award Title
STR_DESC_10		: Description of award
STR_INFO_10		: Additionnal info display for award (only if use by 1 company)
STR_OPT_10_113_14	: (empty)

Here's the STR_OPT_ format:
- first part (in example, it's set to 10) : it's the award number, it must be uniq and must be the same as STR_KEY_x STR_DESC_x and STR_INFO_x
- second part (in example, it's set to 113) : the award type and points.
0 : medal, grant medal points and define award as medal
+1,2 & 3 : define the points grant when the award is win : +1 for easy, +2 medium, +3 hard
+10, 20 or 30 : define the category of the award : 30 MISC, 20 ECONOMY and 10 for VEHICLE.
+100 : define if award can be win by many companies or by one only.

So only valid value for medal is 0, other values mean it's an award
So 113 mean : award can be win by everyone, is of category VEHICLE and will gave Hard points value when win.
- the third part (in example 14) : it's the days delay to check if award is win or not : so 14 days in the example.
You can disable day checks by setting it to 0 value. Per example if award need to be check after an event, there's no need to check it x days.

Next to that you just add the conditions checks in eval.nut as function Scheduler::AwardEvaluate_x() (where is x == the award number).
If days check was define, the script will trigger AwardEvaluate_x function every x day you have define, else it's upto you to add a trigger elsewhere in the code.

