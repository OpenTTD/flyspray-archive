Swedish Rails NewGRF
-----------------------------------

This version: Swedish Rails nightly-r152M

Contents:

1 About
2 Quickstart
3 Usage and parameters
  3.1 Compatibility with other NewGRF
  3.2 Known bugs
4 Building from source
  4.1 Requirements
5 License
6 Credits



-------
1 About
-------

This set provides a replacement for the rail infrastructure in Swedish style
while providing a number of graphical enhancements over the default tracks.

Swedish Rails is designed to work for both, TTDPatch (any version) and
OpenTTD (version 1.0.0 or newer).

It provides completely snow - aware graphics for the rail infrastructure
(except stations). Features include:
- snow-aware depots in old and modern style, different for electric and non-
  electric rails (see parameters; OpenTTD only).
- completely ground-tile independence for all graphics (OpenTTD only)
- new level crossings which match every chosen road style (OpenTTD only)
- optionally new tunnels portals (see parameters)
- new fences (see parameters)

Name of this Repo: Swedish Rails nightly-r152M
GRF_ID:            "SER0"
MD5 sum:           d9769e9bf891eb36ffb18adfae4a8f61  swedishrails.grf

Repository version: 152



--------------
2 Installation
--------------

Download the set from bananas or put the unziped archive into your OpenTTD or
TTDPatch data folder.



----------------------
3 Usage and parameters
----------------------

Just activate it in the NewGRF settings and enjoy.

Parameters:

No 1:   Compatibility
        0 = Use default tunnels (compatible with all base sets, default)
            strongly recommended for multiplayer games
        1: Use OpenGFX - compatible tunnel sprites
        2 or higher: Use TTD - compatible tunnel sprites.
        3 or higher: Disable the use of rail types.
        3: Use default OpenGFX level crossings.
        4: Use TTD - compatible level crossings.
        5: Use TTRS - compatible level crossings.

        Tunnel portal sprites are a bit difficult: they need to match the ground
        tiles - which depend upon the base set being used by the player. In
        multiplayer games different players use different base sets. Thus by
        choosing any tunnel portal by default, this set would glitch for at
        least one third or two thirds of the players (depending upon which
        option one choses). If you play in single player only, you know your
        base set, then feel free to chose the new tunnel portals; they are after
        all nicer than either original :-)
        
        When playing OpenTTD, do not use a parameter value larger than 2 as it
        will interfere with the railtypes feature and produce glitches.
                
No 2:   Introduction year for modern depots. The behaviour depends upon the
        game version used.
                
        OpenTTD > r20003:
        The parameter indicates the introduction year for the modern version of
        the depots. From that year onward all depots newly built will be of the
        new design while old ones retain their old style.
        default introduction year for modern depots: 1975
        
        OpenTTD 1.0.x and nightlies < r20003:
        Introduction year when all graphics start to show the new depot
        version. These versions of OpenTTD don't support a build date of depots,
        as such ALL depot graphics will change their style from old to modern
        over a time span of 15 years starting with this year.
        default introduction year for modern depots: never
        
        TTDPatch or parameter 1 set to 3 or higher:
        From the given year on all depots will be converted to the modern
        version within a range of 15 years.

No 3:   Choice of rail fences
        0 = Use Swedish rail fences
		1 = Use company-coloured fences (the same as Swedish rail fences)
		2 = Use non company-coloured fences
		3 = Use the OpenTTD default fences
		4 = Use no fences

		+10: Apply this setting only for Swedish rails	

        It is recommended to use in multiplayer games the company colour version
        of the fences. It allows to find the owner of a piece of track more
        easily.

No 4:   Introduction year for modern level crossings
        OpenTTD:
        From the given year on all level crossings will be converted to the modern
        version within a range of 15 years.
        Default: same year as modern depots are introduced.
        
        One parameter value is special:
        You can disable all level crossing sprites, if this parameter is set to 1.

        TTDPatch or parameter 1 set to 3:
        On the given year on all level crossings will be converted to the modern
        version instantly.
        Default: same year as modern depots are introduced.
		
No 5:   Allow level crossings
		OpenTTD > r20049:
		0 = allow building of level crossings (default)
		1 = forbid building of level crossings
		
		OpenTTD < r20049, TTDPatch or parameter 1 set to 3:
		Not applicable, no effect.


3.1 Compatibility with other NewGRF
-----------------------------------

- other railtypes newgrfs (OpenTTD only):
  When Swedish Rails is used concurrently with other railtypes newgrfs, conflicts
  may arise when both try to (re-)define the standard train tracks. The order of
  loading the newgrfs will matter. It should work nicley along with railtype
  NewGRFs which only define an additional track type or metro tracks, 3rdRail,
  narrow gauge or alike; but combine at your own risk.
  Untested, but Swedish Rails most probably is incompatible with NuTracks.
  
- road sets (TTDPatch only):
  Make sure that Swedish Rails is loaded AFTER the road set, or it won't be able to
  supply proper level crossing sprites and you may experience glitches.
  
  Swedish Rails currently supports actively the default TTD and TTRS roads, you have
  to select proper support via parameter 1. When used in conjunction with other road
  sets, you'll experience glitches concerning level crossings as the road style might
  not be supported (yet). If a road set specifically supports Swedish Rails, you may
  want to load it after Swedish Rails.


3.2 Known Bugs
--------------
- [TTDP] It is known to crash TTDPatch; but it's most probably TTDPatch bug con-
  cerning parameter handling:(see http://www.tt-forums.net/viewtopic.php?f=24&t=49044
- [OTTD] Bridges show snowy or normal tracks, depending upon the height of the tile
  below it. There's currently not much we can do about it as there's no way to query
  the height of the bridge.
- [OTTD] Snowy version of the tracks is not chosen on tiles where the height of the
  lowest corner would correctly result in non-snowy versions (e.g. on tiles with slopes
  and / or foundations). This is sub-optimal handling of the height information within
  OpenTTD.
- [TTDP] Level crossing replacement in the TTDPatch only work for the default TTD tiles
  and for the total town replacement set (TTRS). The choice of the correct sprites has
  to be made via parameter 1, the presence of other newgrfs is not yet tested for.
- [TTDP] The Swedish style level crossings are known to glitch a bit due to missing
  bounding boxes for the level crossing tiles.



----------------------
4 Building from source
----------------------

Before this build system can be applied to a newgrf, you have to adopt a few
lines in Makefile.config, mainly you'll have to replace "mynewgrf" by the actual
name of your newgrf. Also make sure to change that in the .hgignore file.

The Makefile offers different targets. A brief overview is given here:

all: 
This is the default target, if also no parameter is given to make. It will
simply build the grf file, if it needs building

bundle:
This target will create a directory called "<name>-nightly" and copy the grf
file there and the documentation files, readme.txt, changelog.txt and
license.txt

bundle_zip
This will zip the bundle directory into one zip for distribution

bundle_tar
This will tar the bundle directory into a tar archive for distribution or upload
to bananas

bundle_src
Creates a source bundle

install:
This will create a tar archive (like bundle_tar) and copy it into the INSTALLDIR
as specified in Makefile.local (or the default dir, if that isn't defined).
Don't rely on a good detection of the default installation directory. It's
especially bound to fail on windows machines.

distclean:
This phony target cleans everything from a source bundle which wasn't shipped.

clean:
This phony target will delete all files which this Makefile will create

mrproper:
This phony target will delete also all directories created by different Makefile
targets

remake:
It's a shortcut for first cleaning the dir and then making the grf anew.


4.1 Requirements
----------------

In order to build this newgrf from source you need:
- python 2.5+ with yacc, pil modules installed
- NML r500 or newer
- make 3.80+
- gcc as pre-processor
- some small shell tools: cat, sed

and optionally:
- unix2dos possibly for conversion of the documentation files
- tar for creating bundles
- zip for creating bundles



---------
5 License
---------

This generic NewGRF is drawn by Irwe and was written by Ingo von Borstel (aka
planetmaker). It is free to use for anyone under the terms of the GNU Pulic
License v2 or higher. See license.txt.

The source code can be obtained from the #openttdcoop DevZone at
http://dev.openttdcoop.org/projects/swedishrails
or via mercurial checkout 
hg clone http://dev.openttdcoop.org/projects/swedishrails



---------
6 Credits
---------

Coding: Ingo von Borstel (aka planetmaker)
Graphics: Irwe

Special thanks to Ammler who provides and works a lot on maintaining the
Development Zone where this repository is hosted and who also frequently gives
much valuable input. Special thanks also to Yexo, Hirundo and Alberth who
stomped from ground in nearly no time the amazing newgrf language NML this
project is written in and which is one of the reasons it could be created so
quickly. Thanks to DJ Nekkid for his idea of using the random bits in order to
define a transition period for introduction of modern versions (depots and
level crossings)
