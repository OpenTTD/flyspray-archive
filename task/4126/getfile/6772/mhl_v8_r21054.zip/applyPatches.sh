# This call is outcommented on purpose.  This file adds the BridgeTooHighMessage 
# patch generated relatively to trunk.  As terraform_cmd.cpp is also changed by
# other patches, we commented this call out, and instead added an adjusted helper
# patch below, which can be applied to a working copy with the other patches
# already applied.
# This patch does not depend on any other patches.
#patch -p0 < patches/mhl_BridgeTooHighMessage_v1_r20903.diff

# Does not depend on anything
patch -p0 < patches/mhl_GeometryOutsideMap_v1_r20854.diff

# Does not depend on anything
patch -p0 < patches/mhl_HeightInLandInfo_v1_r20920.diff

# Does not depend on anything
patch -p0 < patches/mhl_PaintingVoidTiles_v2_r20854.diff

# Does not depend on anything
patch -p0 < patches/mhl_ScreenShot_v1_r20914.diff

# Does not depend on anything
patch -p0 < patches/mhl_Terraformer_v3_r20823.diff

# The mhl_Help_ViewPort patch is the Viewport_v3 patch minus the change that will
# be added in the Help_CorrectMarkTileDirty_v2 patch.  (this change would fail if
# it would be in the mhl_ViewPort patch, as there it is generated relatively to
# trunk, but here trunk was already changed by the patches above).
# So: The mhl_ViewPort_v3 patch is the patch containing all changes that conceptionally
# belong to the ViewPort patch.  But, it can't be applied here, as in original form,
# it conflicts with other patches applied before.
# ViewPort depends on both PaintingVoidTiles and GeometryOutsideMap
#patch -p0 < patches/mhl_ViewPort_v3_r21005.diff
patch -p0 < patches/mhl_Help_ViewPort.diff

patch -p0 < patches/mhl_Help_CorrectMarkTileDirty_v2.diff

# SmallMapPos depends on the ViewPort patch.
patch -p0 < patches/mhl_SmallMapPos_v1_r20857.diff

# Does not depend on anything
patch -p0 < patches/mhl_SaveGameBase_v2_r20918.diff

# Depends on the SaveGameBase patch
patch -p0 < patches/mhl_VehiclesBase_v1_r20894.diff

# The following patches do not depend on any other patches, and also not on each other
patch -p0 < patches/mhl_Road_v1_r20894.diff
patch -p0 < patches/mhl_Train_v1_r20902.diff
patch -p0 < patches/mhl_Tree_v1_r20902.diff
patch -p0 < patches/mhl_TunnelBridge_v1_r20902.diff
patch -p0 < patches/mhl_VehicleCommon_v2_r20920.diff

# This patch depends on the GeometryOutsideMap, SaveGameBase and VehiclesBase patches.
patch -p0 < patches/mhl_Aircrafts_v1_r20904.diff

# This patch depends on the GeometryOutsideMap, SaveGameBase, VehiclesBase and Aircraft patches.
patch -p0 < patches/mhl_Disaster_v2_r21005.diff

# This patch depends on the SaveGameBase patch
patch -p0 < patches/mhl_Signs_v1_r20914.diff


# The same idea as for mhl_Help_ViewPort above.
# The Core patch technically depends on not many patches.  But it enables more
# heightlevels for the player.
#patch -p0 < patches/mhl_Core_v2_r21005.diff
patch -p0 < patches/mhl_Help_Core.diff

patch -p0 < patches/mhl_Help_TileMap.diff

patch -p0 < patches/mhl_ViewPortAfterCore_v1_r20919.diff

# Depends on Core, UsingCorrect_HeightLegendArray and HeightLegend_BreakMarker
patch -p0 < patches/mhl_Smallmap_Extending_HeightLegendArray_v3_r21005.diff

# Depends on Core, Smallmap_Extending_HeightLegendArray and Smallmap_HeightLegend_BreakMarker
# => Apply this and the next patch together
patch -p0 < patches/mhl_Smallmap_UsingCorrect_HeightLegendArray_v1_r20920.diff

# Depends on Smallmap_Extending_HeightLegendArray and Smallmap_UsingCorrect_HeightLegendArray
patch -p0 < patches/mhl_Smallmap_HeightLegend_BreakMarker_v1_r20920.diff


# Depends on Core
patch -p0 < patches/mhl_Generating_Higher_Maps_v2_r21005.diff

# Depends on Core and Generating_Higher_Maps
patch -p0 < patches/mhl_Choosing_HeightmapHeight_v2_r21037.diff

# Depends on Generating_Higher_Maps
patch -p0 < patches/mhl_Industry_Levelling_v1_r20920.diff

# Apply these patches in this order
patch -p1 < patches/mhl_Snowline_v1_r21039.diff
patch -p1 < patches/mhl_Flat_Land_Height_v1_r21039.diff
patch -p1 < patches/mhl_Additional_Comments_v1_r21039.diff

patch -p1 < patches/mhl_Help_BridgeTooHeightMessage.diff