patch -p0 < patches/mhl_Aircrafts_v1_r20904.diff
#patch -p0 < patches/mhl_BridgeTooHighMessage_v1_r20903.diff
patch -p0 < patches/mhl_Disaster_v2_r21005.diff
patch -p0 < patches/mhl_GeometryOutsideMap_v1_r20854.diff
patch -p0 < patches/mhl_HeightInLandInfo_v1_r20920.diff
patch -p0 < patches/mhl_PaintingVoidTiles_v2_r20854.diff
patch -p0 < patches/mhl_Road_v1_r20894.diff
patch -p0 < patches/mhl_SaveGameBase_v2_r20918.diff
patch -p0 < patches/mhl_ScreenShot_v1_r20914.diff
patch -p0 < patches/mhl_Signs_v1_r20914.diff
patch -p0 < patches/mhl_SmallMapPos_v1_r20857.diff
patch -p0 < patches/mhl_Terraformer_v3_r20823.diff
patch -p0 < patches/mhl_Train_v1_r20902.diff
patch -p0 < patches/mhl_Tree_v1_r20902.diff
patch -p0 < patches/mhl_TunnelBridge_v1_r20902.diff
patch -p0 < patches/mhl_VehicleCommon_v2_r20920.diff
patch -p0 < patches/mhl_VehiclesBase_v1_r20894.diff
patch -p0 < patches/mhl_ViewPort_v3_r21005.diff

patch -p0 < patches/mhl_Help_CorrectMarkTileDirty_v2.diff

patch -p0 < patches/mhl_Core_v2_r21005.diff

patch -p0 < patches/mhl_Help_TileMap.diff

patch -p0 < patches/mhl_ViewPortAfterCore_v1_r20919.diff

patch -p0 < patches/mhl_Smallmap_Extending_HeightLegendArray_v3_r21005.diff
patch -p0 < patches/mhl_Smallmap_HeightLegend_BreakMarker_v1_r20920.diff
patch -p0 < patches/mhl_Smallmap_UsingCorrect_HeightLegendArray_v1_r20920.diff
patch -p0 < patches/mhl_Generating_Higher_Maps_v2_r21005.diff
patch -p0 < patches/mhl_Choosing_HeightmapHeight_v1_r20920.diff
patch -p0 < patches/mhl_Industry_Levelling_v1_r20920.diff