# This call is outcommented on purpose.  This file adds the BridgeTooHighMessage 
# patch generated relatively to trunk.  As terraform_cmd.cpp is also changed by
# other patches, we commented this call out, and instead added an adjusted helper
# patch below, which can be applied to a working copy with the other patches
# already applied.
# This patch does not depend on any other patches.
#patch -p0 < patches/mhl_BridgeTooHighMessage_v1_r20903.diff

echo "Applying GeometryOutsideMap - Does not depend on anything"
patch -p0 < patches/mhl_GeometryOutsideMap_v1_r20854.diff

echo "Applying PaintingVoidTiles - Does not depend on anything"
patch -p0 < patches/mhl_PaintingVoidTiles_v2_r20854.diff

echo "Applying ScreenShot - Does not depend on anything"
patch -p0 < patches/mhl_ScreenShot_v1_r20914.diff

echo "Applying Terraformer - Does not depend on anything"
patch -p0 < patches/mhl_Terraformer_v3_r20823.diff

# The mhl_Help_ViewPort patch is the Viewport_v4 patch minus the change that will
# be added in the Help_CorrectMarkTileDirty_v2 patch.  (this change would fail if
# it would be in the mhl_ViewPort patch, as there it is generated relatively to
# trunk, but here trunk was already changed by the patches above).
# So: The mhl_ViewPort_v4 patch is the patch containing all changes that conceptionally
# belong to the ViewPort patch.  But, it can't be applied here, as in original form,
# it conflicts with other patches applied before.
# ViewPort depends on both PaintingVoidTiles and GeometryOutsideMap
#patch -p0 < patches/mhl_ViewPort_v4_r21057.diff
echo "Applying ViewPort - Depends on PaintingVoidTiles and GeometryOutsideMap"
patch -p0 < patches/mhl_Help_ViewPort_v2.diff

patch -p0 < patches/mhl_Help_CorrectMarkTileDirty_v2.diff

echo "Applying SmallMapPos - Depends on ViewPort"
patch -p0 < patches/mhl_SmallMapPos_v2_r21057.diff

echo "Applying SaveGameBase - Does not depend on anything"
patch -p0 < patches/mhl_SaveGameBase_v2_r20918.diff

echo "Applying VehiclesBase - Depends on SaveGameBase"
patch -p0 < patches/mhl_VehiclesBase_v1_r20894.diff

echo "Applying Road - Does not depend on anything"
patch -p0 < patches/mhl_Road_v1_r20894.diff

echo "Applying Train - Does not depend on anything"
patch -p0 < patches/mhl_Train_v2_r21057.diff

echo "Applying Tree - Does not depend on anything"
patch -p0 < patches/mhl_Tree_v1_r20902.diff

echo "Applying TunnelBridge - Does not depend on anything"
patch -p0 < patches/mhl_TunnelBridge_v1_r20902.diff

echo "Applying VehicleCommon - Does not depend on anything"
patch -p0 < patches/mhl_VehicleCommon_v2_r20920.diff

echo "Applying Aircrafts - Depends on GeometryOutsideMap, SaveGameBase and VehiclesBase"
patch -p0 < patches/mhl_Aircrafts_v2_r21056.diff

echo "Applying Disaster - Depends on GeometryOutsideMap, SaveGameBase, VehiclesBase and Aircrafts"
patch -p0 < patches/mhl_Disaster_v3_r21056.diff

echo "Applying Signs - Depends on SaveGameBase"
patch -p0 < patches/mhl_Signs_v1_r20914.diff


# The same idea as for mhl_Help_ViewPort above.
# The Core patch technically depends on not many patches.  But it enables more
# heightlevels for the player.
#patch -p0 < patches/mhl_Core_v3_r21005.diff
echo "Applying Core"
patch -p0 < patches/mhl_Help_Core_v3.diff

patch -p0 < patches/mhl_Help_TileMap_v2.diff

echo "Applying ViewPortAfterCore - Depends on Core and ViewPort"
patch -p0 < patches/mhl_ViewPortAfterCore_v1_r20919.diff

echo "Applying Smallmap_Extending_HLA"
# Depends on Core, UsingCorrect_HeightLegendArray and HeightLegend_BreakMarker
patch -p0 < patches/mhl_Smallmap_Extending_HeightLegendArray_v3_r21005.diff

# Depends on Core, Smallmap_Extending_HeightLegendArray and Smallmap_HeightLegend_BreakMarker
# => Apply this and the next patch together
echo "Applying Smallmap_UsingCorrect_HLA"
patch -p0 < patches/mhl_Smallmap_UsingCorrect_HeightLegendArray_v1_r20920.diff

# Depends on Smallmap_Extending_HeightLegendArray and Smallmap_UsingCorrect_HeightLegendArray
echo "Applying Smallmap_HeightLegend_BreakMarker"
patch -p0 < patches/mhl_Smallmap_HeightLegend_BreakMarker_v1_r20920.diff

# From here on, applying the patches in the order they are given here is the best option
# (sometimes, they are generated based on each other, changing the same portion of a file twice)
# Depends on Core and Generating_Higher_Maps
echo "Applying Choosing_HeightmapHeight"
patch -p0 < patches/mhl_Choosing_HeightmapHeight_v3_r21037.diff

# Depends on Core; is not essential for the patch
# echo "Applying Generating_Higher_Maps - Depends on Core and Choosing_HeightmapHeight, but is not essential for the patch"
patch -p0 < patches/mhl_Generating_Higher_Maps_v4_r21005.diff

# Depends on Generating_Higher_Maps, is not essential for the patch
echo "Applying Industry_Levelling"
patch -p0 < patches/mhl_Industry_Levelling_v2_r20920.diff

# Apply these patches in this order
echo "Applying Snowline"
patch -p0 < patches/mhl_Snowline_v3_r21105.diff

echo "Applying Flat_Land_Height"
patch -p0 < patches/mhl_Flat_Land_Height_v3_r21105.diff

echo "Applying Additional_Comments"
patch -p1 < patches/mhl_Additional_Comments_v1_r21039.diff

echo "Applying Help_BridgeTooHighMessage"
patch -p1 < patches/mhl_Help_BridgeTooHeightMessage.diff

echo "Applying OldMapGenerator"
patch -p0 < patches/mhl_OldMapGenerator_v1_r21105.diff