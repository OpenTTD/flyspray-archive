To potential coder that wants to reuse my code:
- I attempted to transfer any reusable code to superlib
- note that I use modified version of API, see myAPIpatch.nut