Swedish Rails NewGRF
-----------------------------------

This version: Swedish Rails nightly-r64M

Contents:

1 About
2 Quickstart
3 Installation
4 Building from source
5 License
6 Credits



-------
1 About
-------

This set provides a replacement for the default rail tracks in Swedish style

Name of this Repo: Swedish Rails nightly-r64M
GRF_ID:            "SER" 00
MD5 sum:           e9cbf486ffddb332053dda9fd9da67c8  swedishrails.grf

Repository version: 64



--------------
2 Installation
--------------

Download the set from bananas or put the unziped archive into your OpenTTD or
TTDPatch data folder.



----------------------
3 Usage
----------------------

Just activate it in the NewGRF settings and enjoy.

Parameters:

param0:	tunnels sprites to use
        0 = Use default tunnels (compatible with all base sets, default)
        1 = Use TTD - compatible tunnel sprites.
        2 = Use OpenGFX - compatible tunnel sprites
param1: introduction year for modern depots
        0 = 1975 / never* (default)
        else: introduction year
		* for OpenTTD > r20003 the introduction year sets the date when new
		  depots will be built in the modern style. Earlier versions of
		  OpenTTD don't support this; thus the parameter sets the date when
		  ALL depots change their style from old to modern.
param2: Choice of rail fences
        0 = Use swedish rail fences whereever possible (default)
		1 = Use fences only with own rails (OpenTTD only)
		1 = Use no fences at all


3.1 Known Bugs
--------------
- In TTDPatch the level crossings will not look right. Those sprites are still
  missing.
- In OpenTTD the level crossings will have no lights, Those sprites are still
  missing.
- Bridges don't yet support SwedishRails.
- Depots are not yet snow aware.


----------------------
4 Building from source
----------------------

Before this build system can be applied to a newgrf, you have to adopt a few
lines in Makefile.config, mainly you'll have to replace "mynewgrf" by the actual
name of your newgrf. Also make sure to change that in the .hgignore file.

The Makefile offers different targets. A brief overview is given here:

all: 
This is the default target, if also no parameter is given to make. It will
simply build the grf file, if it needs building

bundle:
This target will create a directory called "<name>-nightly" and copy the grf
file there and the documentation files, readme.txt, changelog.txt and
license.txt

bundle_zip
This will zip the bundle directory into one zip for distribution

bundle_tar
This will tar the bundle directory into a tar archive for distribution or upload
to bananas

bundle_src
Creates a source bundle

install:
This will create a tar archive (like bundle_tar) and copy it into the INSTALLDIR
as specified in Makefile.local (or the default dir, if that isn't defined).
Don't rely on a good detection of the default installation directory. It's
especially bound to fail on windows machines.

distclean:
This phony target cleans everything from a source bundle which wasn't shipped.

clean:
This phony target will delete all files which this Makefile will create

mrproper:
This phony target will delete also all directories created by different Makefile
targets

remake:
It's a shortcut for first cleaning the dir and then making the grf anew.


4.1 Setup
---------

You'll need to adopt the repository to your new NewGRF. There are a few files
which need modification:
- Makefile.config
- .hgignore
- docs/changelog.ptxt
- docs/readme.ptxt
- docs/license.ptxt (you may choose GPL v2 or newer, if you use this template
  newgrf and / or build system)



---------
5 License
---------

This generic NewGRF is drawn by Irwe and was written by Ingo von Borstel (aka
planetmaker). It is free to use for anyone under the terms of the GNU Pulic
License v2 or higher. See license.txt.

The source code can be obtained from the #openttdcoop DevZone at
http://dev.openttdcoop.org/projects/swedishrails
or via mercurial checkout 
hg clone http://dev.openttdcoop.org/projects/swedishrails



---------
6 Credits
---------

Coding: Ingo von Borstel (aka planetmaker)
Graphics: Irwe

Special thanks to #openttdcoop and especially Ammler who provides and works a
lot on maintaining the Development Zone where this repository is hosted and who
also frequently gives much valuable input. Thanks also to all the NewGRF authors
whose NewGRFs can be my playground for this project. 
